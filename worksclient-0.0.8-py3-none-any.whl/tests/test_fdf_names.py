import pytest
import worksclient as wc
import responses


@responses.activate
def test_legacy_path_request():
    query_string = "?format=json&flight_id=1&field_id=2&mosaic_block_letter=Z"
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/registered/{}".format(query_string),
        match_querystring=True,
        json={"path": "Flight 666/fake/path.tif"},
    )
    res = wc.FDFPath.get("registered", flight_id=1, field_id=2, mosaic_block_letter="Z")
    assert len(responses.calls) == 1
    assert res["path"] == "Flight 666/fake/path.tif"


@responses.activate
def test_empty_mosaic_block_excluded():
    query_string = "?format=json&flight_id=1&field_id=2"
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/registered/{}".format(query_string),
        match_querystring=True,
        json={"path": "Flight 666/fake/path_v2.tif"},
    )
    res = wc.FDFPath.get(
        "registered",
        flight_id=1,
        field_id=2,
        mosaic_block_letter="",
        parameter_set="default",
    )
    assert len(responses.calls) == 1
    assert res["path"] == "Flight 666/fake/path_v2.tif"


@responses.activate
def test_default_param_set_becomes_None():
    query_string = "?format=json&flight_id=1&field_id=2&mosaic_block_letter=Z"
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/registered/{}".format(query_string),
        match_querystring=True,
        json={"path": "Flight 666/fake/path_v2.tif"},
    )
    res = wc.FDFPath.get(
        "registered",
        flight_id=1,
        field_id=2,
        mosaic_block_letter="Z",
        parameter_set="default",
    )
    assert len(responses.calls) == 1
    assert res["path"] == "Flight 666/fake/path_v2.tif"


@responses.activate
def test_legacy_path_request_with_parameter_set():
    query_string = (
        "?format=json&flight_id=1&field_id=2&mosaic_block_letter=Z&param_set=v2"
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/registered/{}".format(query_string),
        match_querystring=True,
        json={"path": "Flight 666/fake/path_v2.tif"},
    )
    res = wc.FDFPath.get(
        "registered",
        flight_id=1,
        field_id=2,
        mosaic_block_letter="Z",
        parameter_set="v2",
    )
    assert len(responses.calls) == 1
    assert res["path"] == "Flight 666/fake/path_v2.tif"


@responses.activate
def test_None_params_not_sent():
    query_string = "?format=json&flight_id=1&field_id=2"
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/registered/{}".format(query_string),
        match_querystring=True,
        json={"path": "Flight 666/fake/path_v2.tif"},
    )
    res = wc.FDFPath.get(
        "registered",
        flight_id=1,
        field_id=2,
        mosaic_block_letter=None,
        parameter_set=None,
    )
    assert len(responses.calls) == 1
    assert res["path"] == "Flight 666/fake/path_v2.tif"


@responses.activate
def test_endpoint_error():
    query_string = "?format=json&flight_id=1&field_id=2"
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/registered/{}".format(query_string),
        match_querystring=True,
        json={"error": "some error"},
        status=400,
    )
    res = wc.FDFPath.get(
        "registered",
        flight_id=1,
        field_id=2,
        mosaic_block_letter=None,
        parameter_set=None,
    )
    assert len(responses.calls) == 1
    assert res["error"] == "some error"


@responses.activate
def test_get_naip():
    query_string = "?format=json&field_id=2"
    responses.add(
        responses.GET,
        wc.api_base + "/api/fdf_path/naip/{}".format(query_string),
        match_querystring=True,
        json={"path": "Georegistered/NAIP/1/2.tif"},
        status=200,
    )
    res = wc.FDFPath.get("naip", field_id=2)
    assert len(responses.calls) == 1
    assert res["path"] == "Georegistered/NAIP/1/2.tif"
