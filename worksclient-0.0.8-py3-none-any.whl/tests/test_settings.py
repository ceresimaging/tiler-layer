import responses
import worksclient as wc


@responses.activate
def test_retrieve_settings():
    responses.add(
        responses.GET,
        wc.api_base
        + "/api/users/settings/?user_id=1&user_id=2&format=json&setting=notifications.imagery",
        json={"json": "test"},
        status=200,
        match_querystring=True,
    )

    resp = wc.UserSettings.list("notifications.imagery", user_ids=[1, 2])
    assert resp["json"] == "test"
