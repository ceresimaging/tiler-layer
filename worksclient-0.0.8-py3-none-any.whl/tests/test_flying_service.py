import responses
import worksclient as wc


mock_response = {
    "id": 30,
    "name": "High Level Airport",
    "active": False,
    "price_per_hour": None,
    "number_of_planes": None,
    "internet_upload_speed": None,
    "physical_address": None,
    "flying_range": 100,
    "coordinates": {"type": "Point", "coordinates": [-117.135, 58.5164]},
    "region": None,
    "user": None,
    "current_camera_system": None,
}


@responses.activate
def test_flying_services_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/flying_services/?format=json",
        json=[mock_response],
        status=200,
        match_querystring=True,
    )

    resp = wc.FlyingService.list()
    assert resp == [mock_response]


@responses.activate
def test_flying_services_retrieve():
    responses.add(
        responses.GET,
        wc.api_base + "/api/flying_services/30/?format=json",
        json=mock_response,
        status=200,
        match_querystring=True,
    )

    resp = wc.FlyingService.retrieve(mock_response["id"])
    assert resp == mock_response
