from datetime import datetime

import responses

import worksclient as wc

sample_response_tested = {
    "id": 144,
    "reference_camera": 13,
    "warp_camera": 21,
    "flight": 3333,
    "reference_trim": 75,
    "warp_trim": 75,
    "images_collected_at": "2016-07-24T00:00:00-07:00",
    "created_at": "2019-06-13T07:21:50.415072-07:00",
    "updated_at": "2019-06-13T07:21:50.415072-07:00",
    "invalidated_at": None,
    "author": "Anonymous Aligner",
    "test_passed": True,
    "tiepoints_warp_camera": [
        [232.0, 197.0],
        [210.0, 872.0],
        [1148.0, 215.0],
        [1125.0, 847.0],
    ],
    "tiepoints_reference_camera": [
        [232.0, 197.0],
        [210.0, 873.0],
        [1150.0, 216.0],
        [1125.0, 848.0],
    ],
}

sample_response_untested = {
    "id": 144,
    "reference_camera": 13,
    "warp_camera": 21,
    "flight": 3333,
    "reference_trim": 0,
    "warp_trim": 75,
    "images_collected_at": "2016-07-24T00:00:00-07:00",
    "created_at": "2019-06-13T07:21:50.415072-07:00",
    "updated_at": "2019-06-13T07:21:50.415072-07:00",
    "invalidated_at": None,
    "author": "Anonymous Aligner",
    "test_passed": False,
    "tiepoints_warp_camera": [
        [232.0, 197.0],
        [210.0, 872.0],
        [1148.0, 215.0],
        [1125.0, 847.0],
    ],
    "tiepoints_reference_camera": [
        [232.0, 197.0],
        [210.0, 873.0],
        [1150.0, 216.0],
        [1125.0, 848.0],
    ],
}


@responses.activate
def test_ilatiepoint_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/ila_tiepoints/?format=json",
        json=[sample_response_tested],
        status=200,
        match_querystring=True,
    )

    resp = wc.ILATiePoint.list()
    assert len(resp) == 1
    assert resp[0]["reference_camera"] == 13
    assert resp[0]["warp_camera"] == 21
    assert len(resp[0]["tiepoints_warp_camera"]) == 4


@responses.activate
def test_ilatiepoint_retrieve():
    responses.add(
        responses.GET,
        wc.api_base + "/api/ila_tiepoints/144/?format=json",
        json=[sample_response_tested],
        status=200,
        match_querystring=True,
    )

    resp = wc.ILATiePoint.retrieve(144)
    assert len(resp) == 1
    assert resp[0]["reference_camera"] == 13
    assert resp[0]["warp_camera"] == 21
    assert resp[0]["id"] == 144
    assert len(resp[0]["tiepoints_warp_camera"]) == 4


@responses.activate
def test_ilatiepoint_create():
    responses.add(
        responses.POST,
        wc.api_base + "/api/ila_tiepoints/?format=json",
        json=[sample_response_untested],
        status=201,
        match_querystring=True,
    )

    now = datetime.now()
    resp = wc.ILATiePoint.create(
        13,
        21,
        now,
        sample_response_untested["tiepoints_warp_camera"],
        sample_response_untested["tiepoints_reference_camera"],
        flight_id=666,
        reference_trim=0,
        warp_trim=75,
    )
    assert len(resp) == 1
    assert resp[0]["reference_camera"] == 13
    assert resp[0]["warp_camera"] == 21
    assert resp[0]["warp_trim"] == 75
    assert resp[0]["reference_trim"] == 0
    assert resp[0]["id"] == 144
    assert resp[0]["test_passed"] is False
    assert len(resp[0]["tiepoints_warp_camera"]) == 4
    assert resp[0]["flight"] == 3333


@responses.activate
def test_ilatiepoint_get_production_solution():
    url = "/api/ila_tiepoints/production/{}/{}/".format(
        sample_response_tested["reference_camera"],
        sample_response_tested["warp_camera"],
    )
    responses.add(
        responses.GET,
        wc.api_base + url,
        json=sample_response_tested,
        status=200,
        match_querystring=False,
    )

    resp = wc.ILATiePoint.get_production_solution(13, 21)
    assert resp["reference_camera"] == 13
    assert resp["warp_camera"] == 21
    assert resp["id"] == 144
    assert resp["test_passed"] is True
    assert len(resp["tiepoints_warp_camera"]) == 4


@responses.activate
def test_ilatiepoint_get_production_solution_datefilt():
    url = "/api/ila_tiepoints/production/{}/{}/?format=json&flight_date=2019-10-10T12:00:00".format(
        sample_response_tested["reference_camera"],
        sample_response_tested["warp_camera"],
    )
    responses.add(
        responses.GET,
        wc.api_base + url,
        json=sample_response_tested,
        status=200,
        match_querystring=True,
    )

    resp = wc.ILATiePoint.get_production_solution(
        13, 21, flight_date="2019-10-10T12:00:00"
    )
    assert resp["id"] == 144


@responses.activate
def test_ilatiepoint_get_last_untested_solution():
    url = "/api/ila_tiepoints/testing/{}/{}/".format(
        sample_response_untested["reference_camera"],
        sample_response_untested["warp_camera"],
    )
    responses.add(
        responses.GET,
        wc.api_base + url,
        json=sample_response_untested,
        status=200,
        match_querystring=False,
    )

    resp = wc.ILATiePoint.get_testing_solution(13, 21)
    assert resp["reference_camera"] == 13
    assert resp["warp_camera"] == 21
    assert resp["id"] == 144
    assert resp["test_passed"] is False
    assert len(resp["tiepoints_warp_camera"]) == 4


@responses.activate
def test_ilatiepoint_approve_solution():
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/ila_tiepoints/144/?format=json",
        json=[sample_response_tested],
        status=200,
    )
    # this mocks the use of get_ila_solution() from within the actual
    # approve_ila_solution() function.
    url = "/api/ila_tiepoints/testing/{}/{}/".format(
        sample_response_untested["reference_camera"],
        sample_response_untested["warp_camera"],
    )
    responses.add(
        responses.GET,
        wc.api_base + url,
        json=sample_response_untested,
        status=200,
        match_querystring=False,
    )

    resp = wc.ILATiePoint.approve_ila_solution(13, 21)
    assert len(resp) == 1
    assert resp[0]["warp_camera"] == 21
    assert resp[0]["id"] == 144
    assert resp[0]["test_passed"] is True
    assert len(resp[0]["tiepoints_warp_camera"]) == 4


@responses.activate
def test_flightilatiepoint_get():
    url = "/api/flight/{}/ila_tiepoints?format=json".format(
        sample_response_tested["flight"]
    )
    expected_response = {"vnir550": sample_response_tested}
    responses.add(
        responses.GET,
        wc.api_base + url,
        json=expected_response,
        status=200,
        match_querystring=True,
    )

    resp = wc.FlightILATiePoints.get(3333)
    assert resp == expected_response


@responses.activate
def test_flightilatiepoint_get_untested():
    url = "/api/flight/{}/ila_tiepoints?format=json&allow_untested=True".format(
        sample_response_tested["flight"]
    )
    expected_response = {"vnir550": sample_response_tested}
    responses.add(
        responses.GET,
        wc.api_base + url,
        json=expected_response,
        status=200,
        match_querystring=True,
    )

    resp = wc.FlightILATiePoints.get(3333, allow_untested=True)
    assert resp == expected_response
