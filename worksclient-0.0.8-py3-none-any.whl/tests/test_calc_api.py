import pytest
import worksclient as wc


@pytest.mark.realserver
def test_image_footprint_calculation():
    params = {
        "latitude": 42.3305027,
        "longitude": -72.6553191,
        "altitude": 500,
        "cam_id": 99,
    }

    response = wc.ImageSelectionFootprint.calculate(**params)
    assert isinstance(response, dict)
    assert "type" in response
    assert "coordinates" in response
    assert isinstance(response["coordinates"], list)
