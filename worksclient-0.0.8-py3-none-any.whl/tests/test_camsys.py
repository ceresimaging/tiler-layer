import json
import urllib
from datetime import datetime

import pytest
import responses

import worksclient as wc


@responses.activate
def test_camsys_list():
    with open("tests/data/list_camsys.json") as f:
        data = json.load(f)
        responses.add(responses.GET, wc.api_base + "/api/camsystems/", json=data)
    resp = wc.CamSystem.list()
    assert data == resp
    assert len(resp) == 2


@responses.activate
def test_camsys_get_most_recent_camera():
    name = "Liber 15"
    params = {"format": "json", "name": name, "order": "-id"}
    try:
        params = urllib.parse.urlencode(params)
    except AttributeError:
        params = urllib.urlencode(params)

    with open("tests/data/recent_camsys.json") as f:
        responses.add(
            responses.GET,
            wc.api_base + "/api/camsystems/?{}".format(params),
            json=json.load(f),
        )
    resp = wc.CamSystem.get_most_recent_camera(name)
    assert resp["id"] == 63


@responses.activate
def test_camsys_get_most_recent_camera_nonexistent():
    name = "Liber"
    params = {"format": "json", "name": name, "order": "-id"}
    try:
        params = urllib.parse.urlencode(params)
    except AttributeError:
        params = urllib.urlencode(params)

    with open("tests/data/recent_camsys.json") as f:
        responses.add(
            responses.GET, wc.api_base + "/api/camsystems/?{}".format(params), json=[]
        )
    resp = wc.CamSystem.get_most_recent_camera(name)
    assert resp == {}


@pytest.mark.realserver
def test_camsys_get_stack_order():
    resp = wc.CamSystem.get_stack_order(10)
    assert "0" in resp
    assert resp["0"]["name"] == "vnir800"


@pytest.mark.realserver
def test_camsys_get_ila_order():
    resp = wc.CamSystem.get_ila_order(10)
    assert "0" in resp
    assert resp["0"]["name"] == "vnir670"


@responses.activate
def test_flight_corrections():
    flight_id = 20
    print(wc.api_base + "/api/flights/{}/camera_correction".format(flight_id))
    responses.add(
        responses.GET,
        wc.api_base + "/api/flights/{}/camera_correction".format(flight_id),
        json.dumps({"cam_id": 132, "gamma": None}),
        match_querystring=False,
    )

    resp = wc.FlightCamCorrections.retrieve(flight_id)
    assert "cam_id" in resp
    assert "gamma" in resp


@responses.activate
def test_camcalibration_get():
    data = {
        "id": 1,
        "calibration_date": "2020-09-08T20:12:09-07:00",
        "dark": 23.1,
        "gain": 1.2,
        "offset": 45.1,
        "integration_time": 1221.0,
        "data_directory": None,
        "note": None,
        "cam": 102,
    }
    responses.add(responses.GET, wc.api_base + "/api/camcalibrations/1/", json=data)
    resp = wc.CamCalibration.retrieve(1)
    assert data == resp


@responses.activate
def test_camcalibration_list():
    data = [
        {
            "id": 1,
            "calibration_date": "2020-09-08T20:12:09-07:00",
            "dark": 23.1,
            "gain": 1.2,
            "offset": 121.2,
            "integration_time": 1221.0,
            "data_directory": None,
            "note": None,
            "cam": 102,
        },
        {
            "id": 2,
            "calibration_date": "2020-09-09T10:27:45-07:00",
            "dark": 23.1,
            "gain": 4.0875e-06,
            "offset": 123.2,
            "integration_time": 12.2,
            "data_directory": None,
            "note": None,
            "cam": 12,
        },
    ]
    responses.add(responses.GET, wc.api_base + "/api/camcalibrations/", json=data)
    resp = wc.CamCalibration.list()
    assert data == resp


@responses.activate
def test_camcalibration_create():
    now = datetime.now()
    data = {
        "calibration_date": now.isoformat(),
        "dark": 23.1,
        "gain": 1.2,
        "offset": 214.2,
        "integration_time": 1221.0,
        "data_directory": None,
        "note": None,
        "cam": 102,
    }
    responses.add(
        responses.POST, wc.api_base + "/api/camcalibrations/", json=data, status=201
    )
    resp = wc.CamCalibration.create(
        calibration_date=now,
        dark=data["dark"],
        gain=data["gain"],
        offset=data["offset"],
        integration_time=data["integration_time"],
        cam=data["cam"],
    )
    assert data == resp
