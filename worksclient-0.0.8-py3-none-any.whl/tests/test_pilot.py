import pytest
import worksclient as wc


@pytest.mark.realserver
def test_pilot_update_realserver():
    # test that the real server actually returns a pilot
    wc.auth_token = wc.get_auth_token("guest", "ceres123")
    resp = wc.Pilot.retrieve(1)
    print(resp)
    assert resp["id"] == 1


@pytest.mark.realserver
def test_pilot_list_realserver():
    # test that the real server actually returns a pilot
    resp = wc.Pilot.list()
    assert type(resp) is list
    assert "id" in resp[0].keys()
