import responses

import worksclient as wc

sample_data = {
    "type": "2637814c-dcf0-4d48-8e74-0302a9a211e9",
    "visit": 222127,
    "url": "https://ceres-flights.s3-us-west-2.amazonaws.com/Flight+10023/reflectance/2020-06-04+56386+N-46+VNIR.tif",
}

sample_type_data = {"name": "water_stress", "display_name": "Water Stress"}


@responses.activate
def test_quant_data_create():
    responses.add(
        responses.POST,
        wc.api_base + "/api/quant_data/",
        json=sample_data,
        status=200,
        match_querystring=True,
    )

    resp = wc.QuantitativeData.create(sample_data)
    assert resp == sample_data


@responses.activate
def test_quant_data_type_create():
    responses.add(
        responses.POST,
        wc.api_base + "/api/quant_data/types/",
        json=sample_type_data,
        status=200,
        match_querystring=True,
    )

    resp = wc.QuantitativeDataType.create(sample_data)
    assert resp == sample_type_data
