import pytest
import responses
import worksclient as wc


@responses.activate
def test_product_component_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/product_components/?format=json",
        json=[{"id": 1, "name": "prod 1"}, {"id": 2, "name": "prod 2"}],
        status=200,
        match_querystring=True,
    )

    resp = wc.ProductComponent.list()
    assert resp == [{"id": 1, "name": "prod 1"}, {"id": 2, "name": "prod 2"}]
