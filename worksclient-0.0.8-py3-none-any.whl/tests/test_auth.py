import pytest
import responses

import worksclient as wc


@responses.activate
def test_get_token():
    responses.add(
        responses.POST,
        wc.api_base + "/api/login/?format=json",
        json={"token": "mytoken"},
        status=200,
    )

    token = wc.get_auth_token(username="guest", password="ceres123")
    print("actual token", token)
    assert token == "mytoken"


@pytest.mark.realserver
@pytest.mark.skip
def test_get_token_real():
    token = wc.get_auth_token(username="guest", password="ceres123")
    assert token is not None
