import responses

import worksclient as wc


@responses.activate
def test_create_or_update():
    responses.add(
        responses.POST,
        wc.api_base + "/api/overlays/create_or_update/",
        json={"id": 1},
        status=200,
        match_querystring=True,
    )

    resp = wc.Overlay.create_or_update({})
    assert resp == {"id": 1}


@responses.activate
def test_display_field():
    responses.add(
        responses.POST,
        wc.api_base + "/api/display_field/",
        json={"id": 1},
        status=200,
        match_querystring=True,
    )

    resp = wc.DisplayField.create({})
    assert resp == {"id": 1}


@responses.activate
def test_field_rank():
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/field_rank/1/",
        json={"id": 1},
        status=200,
        match_querystring=True,
    )

    resp = wc.FieldRank.set(1, {})
    assert resp == {"id": 1}
