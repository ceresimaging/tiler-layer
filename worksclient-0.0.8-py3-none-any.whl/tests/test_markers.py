import responses

import worksclient as wc

sample_feature = {
    "type": "Feature",
    "geometry": {
        "type": "Point",
        "coordinates": [-97.98325395232808, 46.23806082340314],
    },
    "properties": {
        "visit": 1,
    },
}

sample_feature_collection = {"type": "FeatureCollection", "features": [sample_feature]}


@responses.activate
def test_marker_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/markers/?format=json",
        json=sample_feature_collection,
        status=200,
        match_querystring=True,
    )

    resp = wc.Marker.list()
    assert resp == sample_feature_collection


@responses.activate
def test_marker_list_page_2():
    responses.add(
        responses.GET,
        wc.api_base + "/api/markers/?format=json&page=2",
        json=sample_feature_collection,
        status=200,
        match_querystring=True,
    )

    resp = wc.Marker.list(page=2)
    assert resp == sample_feature_collection


@responses.activate
def test_marker_retrieve():
    marker_id = "ad50d3a9-8af9-4742-8d79-05f35101ddff"
    responses.add(
        responses.GET,
        wc.api_base + "/api/markers/{}/?format=json".format(marker_id),
        json=sample_feature,
        status=200,
        match_querystring=True,
    )

    resp = wc.Marker.retrieve(marker_id)
    assert resp == sample_feature


@responses.activate
def test_marker_update():
    marker_id = "ad50d3a9-8af9-4742-8d79-05f35101ddff"
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/markers/{}/".format(marker_id),
        json=sample_feature,
        status=200,
        match_querystring=True,
    )

    resp = wc.Marker.update(marker_id, sample_feature)
    assert resp == sample_feature


@responses.activate
def test_marker_delete():
    marker_id = "ad50d3a9-8af9-4742-8d79-05f35101ddff"
    responses.add(
        responses.DELETE,
        wc.api_base + "/api/markers/{}/".format(marker_id),
        json={},
        status=200,
        match_querystring=True,
    )

    resp = wc.Marker.delete(marker_id)
    assert resp == {}
