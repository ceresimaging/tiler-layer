import responses

import worksclient as wc
import requests_mock

sample_satellite_profiles = [
    {
        "id": 6171,
        "name": "EVERGREEN FS RESEARCH PLOT",
        "auto_acres": 6.296653,
        "satellite_capture_profiles": [
            {
                "id": 1,
                "name": "ARM",
                "provider": "SENTINEL",
                "start_date": "2021-01-01",
                "capture_range_start": "2021-05-01",
                "capture_range_end": "2021-09-30",
                "continuous_capture": True,
            }
        ],
    }
]

sample_assets_pending_qa = [
    {
        "profile": 1,
        "field": 73251,
        "date": "2022-02-02",
        "s3_key": "key",
        "file_hash": "dadadcrcdafdddd23",
        "filename": "test.tiff",
        "metadata": {"itemh": "adfasd"},
        "status": "WAITING_QA",
    }
]

sample_assets_passed_qa = [
    {
        "profile": 1,
        "field": 73251,
        "date": "2022-02-02",
        "s3_key": "key",
        "file_hash": "dadadcrcdafdddd23",
        "filename": "test.tiff",
        "metadata": {"itemh": "adfasd"},
        "status": "PASSED_QA",
    }
]

sample_satellite_asset = {
    "profile": 1,
    "field": 73251,
    "date": "2022-02-02",
    "s3_key": "key",
    "file_hash": "dadadcrcdafdddd23",
    "filename": "test.tiff",
    "metadata": {"itemh": "adfasd"},
}


@responses.activate
def test_satellite_fields():
    responses.add(
        responses.GET,
        wc.api_base + "/api/satellite/fields/",
        json=sample_satellite_profiles,
        status=200,
    )

    resp = wc.Satellite.get_fields()
    assert resp == sample_satellite_profiles


@responses.activate
def test_create_satellite_asset():
    responses.add(
        responses.POST,
        wc.api_base + "/api/satellite/assets/",
        json=sample_satellite_asset,
        status=201,
    )

    resp = wc.Satellite.create_asset(data=sample_satellite_asset)
    assert resp == sample_satellite_asset


@responses.activate
def test_get_satellite_asset():
    responses.add(
        responses.GET,
        wc.api_base + "/api/satellite/assets/1/",
        json=sample_satellite_asset,
        status=200,
    )

    resp = wc.Satellite.get_asset(1)
    assert resp == sample_satellite_asset


@responses.activate
def test_get_pending_satellite_assets():
    responses.add(
        responses.GET,
        wc.api_base
        + "/api/satellite/fields/73251/assets/?asset_status=WAITING_QA&format=json",
        json=sample_assets_pending_qa,
        status=200,
    )

    resp = wc.Satellite.get_pending_assets(73251)
    assert resp == sample_assets_pending_qa


@responses.activate
def test_get_approved_satellite_assets():
    responses.add(
        responses.GET,
        wc.api_base
        + "/api/satellite/fields/73251/assets/?asset_status=QA_PASSED&format=json",
        json=sample_assets_passed_qa,
        status=200,
    )

    resp = wc.Satellite.get_approved_assets(73251)
    assert resp == sample_assets_passed_qa


@responses.activate
def test_get_rejected_satellite_assets():
    responses.add(
        responses.GET,
        wc.api_base
        + "/api/satellite/fields/73251/assets/?asset_status=QA_REJECTED&format=json",
        json=sample_assets_passed_qa,
        status=200,
    )

    resp = wc.Satellite.get_rejected_assets(73251)
    assert resp == sample_assets_passed_qa


def test_asset_status_update():
    with requests_mock.Mocker() as m:
        api_adapter = m.post(
            wc.api_base + "/api/satellite/assets/1/change_status/",
            json="{'status': 'success'}",
        )
        wc.Satellite.change_asset_status(1, wc.Satellite.AssetStatus.QA_PASSED)
        assert api_adapter.last_request.json() == {"new_status_name": "QA_PASSED"}
        assert api_adapter.call_count == 1


def test_external_geo_object_status_update():
    with requests_mock.Mocker() as m:
        api_adapter = m.post(
            wc.api_base + "/api/satellite/external_geo_objects/1/change_status/",
            json="{'status': 'success'}",
        )
        wc.Satellite.change_external_geo_object_status(
            1, wc.Satellite.ExternalGeoObjectStatus.READY_TO_DELIVER_REPORT
        )
        assert api_adapter.last_request.json() == {
            "new_status_name": "READY_TO_GENERATE_REPORT"
        }
        assert api_adapter.call_count == 1
