import json
import responses
import worksclient as wc

sample_feature = {
    "type": "Feature",
    "geometry": {
        "type": "Point",
        "coordinates": [-97.98325395232808, 46.23806082340314],
    },
    "properties": {"field_id": 1, "customer_id": "AI corp"},
}

sample_feature_collection = {"type": "FeatureCollection", "features": [sample_feature]}


@responses.activate
def test_sensor_device_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/sensor_devices/?format=json",
        json=sample_feature_collection,
        status=200,
        match_querystring=True,
    )

    resp = wc.SensorDevice.list()
    assert resp == sample_feature_collection


@responses.activate
def test_sensor_device_list_page_2():
    responses.add(
        responses.GET,
        wc.api_base + "/api/sensor_devices/?format=json&page=2",
        json=sample_feature_collection,
        status=200,
        match_querystring=True,
    )

    resp = wc.SensorDevice.list(page=2)
    assert resp == sample_feature_collection


@responses.activate
def test_sensor_device_retrieve():
    print("foooo")
    sensor_device_id = 1
    responses.add(
        responses.GET,
        wc.api_base + "/api/sensor_devices/{}/?format=json".format(sensor_device_id),
        json=sample_feature,
        status=200,
        match_querystring=True,
    )

    resp = wc.SensorDevice.retrieve(sensor_device_id)
    assert resp == sample_feature


@responses.activate
def test_sensor_device_update():
    sensor_device_id = 2
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/sensor_devices/{}/".format(sensor_device_id),
        json=sample_feature,
        status=200,
        match_querystring=True,
    )

    resp = wc.SensorDevice.update(sensor_device_id, sample_feature)
    assert resp == sample_feature
    assert json.loads(responses.calls[0].request.body) == sample_feature


@responses.activate
def test_sensor_device_delete():
    sensor_device_id = 3
    responses.add(
        responses.DELETE,
        wc.api_base + "/api/sensor_devices/{}/".format(sensor_device_id),
        json={},
        status=200,
        match_querystring=True,
    )

    resp = wc.SensorDevice.delete(sensor_device_id)
    assert resp == {}
