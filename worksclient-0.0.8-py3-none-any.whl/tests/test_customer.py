import responses
import worksclient as wc


@responses.activate
def test_customer_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/customers/?format=json",
        json=[{"id": 1, "name": "prod 1"}, {"id": 2, "name": "prod 2"}],
        status=200,
        match_querystring=True,
    )

    resp = wc.Customer.list()
    assert resp == [{"id": 1, "name": "prod 1"}, {"id": 2, "name": "prod 2"}]
