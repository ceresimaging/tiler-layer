import json
import pytest
import responses
import worksclient as wc
import os


def load_geojson():
    geojson = open(os.path.join(wc.DATA_PATH, "shape.json"))
    geojson = geojson.read()
    return geojson


@responses.activate
def test_field_retrieve():
    responses.add(
        responses.GET,
        wc.api_base + "/api/fields/1/?format=json",
        json={"geojson": "test"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Field.retrieve(1, format="json")
    assert resp["geojson"] == "test"


@responses.activate
def test_field_update():
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/fields/1/?format=json",
        json={"geojson": "test"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Field.update(1, load_geojson())
    assert resp is not None


@responses.activate
def test_field_get_geojson_no_block():
    responses.add(
        responses.GET,
        wc.api_base + "/api/fields/1/geos/?format=json",
        json={"geojson": "test"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Field.get_geojson(1)
    assert resp == {"geojson": "test"}


@responses.activate
def test_field_get_geojson_with_block():
    responses.add(
        responses.GET,
        wc.api_base + "/api/fields/1/geos/?mosaic_block=GG&format=json",
        json={"geojson": "test"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Field.get_geojson(1, mosaic_block="GG")
    assert resp == {"geojson": "test"}


@responses.activate
def test_field_get_geojson_compact():
    responses.add(
        responses.GET,
        wc.api_base + "/api/fields/1/geos/?compact=true&format=json",
        json={"type": "MultiPolygon"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Field.get_geojson(1, compact=True)
    assert resp == {"type": "MultiPolygon"}


@responses.activate
def test_field_get_bounding_box():
    responses.add(
        responses.GET,
        wc.api_base + "/api/fields/1/bounding_box/?format=json",
        json={"type": "Polygon"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Field.get_bounding_box(1)
    assert resp == {"type": "Polygon"}


@pytest.mark.realserver
def test_field_update_realserver():
    gj = json.loads(load_geojson())
    resp = wc.Field.update(1685, gj)
    assert "geojson" in resp.keys()


@pytest.mark.realserver
def test_field_list():
    resp = wc.Field.list()
    assert len(resp) > 0
    assert "id" in resp[0]
