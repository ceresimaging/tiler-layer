import pytest
import requests_mock
import worksclient as wc
import sys

if sys.version_info.major < 3:
    FileNotFoundError = IOError


@pytest.mark.realserver
def test_mosaic_block_visit_retrieve():
    resp = wc.MosaicBlockVisit.list()
    get_id = resp[0]["id"]
    resp = wc.MosaicBlockVisit.retrieve(get_id)
    assert resp["id"] == get_id


@pytest.mark.realserver
def test_mosaic_block_visit_list():
    resp = wc.MosaicBlockVisit.list()
    assert type(resp) is list
    assert "id" in resp[0].keys()


@pytest.mark.realserver
def test_mosaic_block_visit_get_mosaic_inputs():
    stack_resp = wc.MosaicBlockVisit.get_mosaic_inputs(20000, "stack")
    assert stack_resp == {
        "images": [
            "Flight 5559/stack/Corrected/ids_band_670_1535395241484.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395243090.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395244688.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395246297.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395247895.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395404958.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395406560.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395408165.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395409767.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395411339.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395412943.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395414544.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395635373.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395636947.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395638546.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395640151.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395641754.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395643357.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395644961.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395769757.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395771358.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395772961.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395774566.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395776168.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395777772.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395779374.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395780990.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395993785.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395995361.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395996964.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535395998569.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396000174.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396001774.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396201762.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396203363.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396204967.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396206570.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396208174.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396209790.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396211380.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396408360.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396409967.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396411533.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396413137.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396414739.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396416354.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396624613.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396626216.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396627819.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396629424.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396631026.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396973444.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396975048.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396976650.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535396978258.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406532853.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406534458.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406536061.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406537665.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406539268.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406540870.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406542475.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406544044.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406545648.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406547252.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406548854.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406550459.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406552061.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406553666.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406555268.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406556872.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406558477.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406560044.tif",
            "Flight 5559/stack/Corrected/ids_band_670_1535406561649.tif",
        ],
        "imu": "Flight 5559/stack/Separated/10438I Black Jack I/stackImuData.txt",
    }

    therm_resp = wc.MosaicBlockVisit.get_mosaic_inputs(20000, "thermal")
    assert therm_resp == {
        "images": [
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395239911.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395241484.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395243091.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395244688.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395246297.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395247895.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395249498.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395403355.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395404958.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395406560.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395408165.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395409767.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395411340.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395412943.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395414544.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395416149.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395635373.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395636947.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395638547.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395640151.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395641754.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395643357.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395644961.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395769757.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395771358.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395772962.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395774567.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395776169.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395777772.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395779375.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395780990.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395992155.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395993785.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395995361.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395996964.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535395998568.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396000174.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396001774.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396201762.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396203363.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396204968.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396206570.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396208174.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396209790.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396211380.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396408360.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396409967.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396411533.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396413137.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396414740.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396416354.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396623009.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396624613.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396626217.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396627820.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396629424.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396631027.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396632631.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396971842.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396973444.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396975048.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396976651.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396978259.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535396979858.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406529653.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406531252.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406532854.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406534458.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406536061.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406537665.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406539269.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406540870.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406542475.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406544044.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406545648.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406547252.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406548854.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406550459.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406552061.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406553666.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406555268.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406556872.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406558477.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406560044.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406561649.png",
            "Flight 5559/Jenoptik/Corrected/jenoptik_1535406563252.png",
        ],
        "imu": "Flight 5559/Jenoptik/Separated/10438I Black Jack I/jenoptikImuData.txt",
        "resolution": "Flight 5559/Jenoptik/Separated/10438I Black Jack I/resolution.txt",
    }


@pytest.mark.realserver
def test_mosaic_block_visit_get_mosaic():
    resp = wc.MosaicBlockVisit.get_mosaic(20000)
    assert resp["stack"] == [
        "Flight 5559/mosaic/2018-08-27 10438 Black Jack I VNIR.tif"
    ]
    assert resp["thermal"] == [
        "Flight 5559/mosaic/2018-08-27 10438 Black Jack I Jenoptik.tif"
    ]


@pytest.mark.realserver
def test_mosaic_block_visit_get_registered():
    resp = wc.MosaicBlockVisit.get_registered(20000)
    assert resp["14739"]["stack"] == [
        "Flight 5316/registered/2018-08-08 10438 Black Jack I VNIR.tif"
    ]
    assert resp["14739"]["thermal"] == [
        "Flight 5316/registered/2018-08-08 10438 Black Jack I Jenoptik.tif"
    ]
    assert resp["17524"]["stack"] == [
        "Flight 5407/registered/2018-08-16 10438 Black Jack I VNIR.tif"
    ]
    assert resp["17524"]["thermal"] == [
        "Flight 5407/registered/2018-08-16 10438 Black Jack I Jenoptik.tif"
    ]


@pytest.mark.realserver
def test_mosaic_block_visit_temp_urls():
    resp = wc.MosaicBlockVisit.get_registered(20000, temp_url=True)
    assert resp["14739"]["stack"][0].startswith("https")
    assert resp["14739"]["thermal"][0].startswith("https")
    assert resp["17524"]["stack"][0].startswith("https")
    assert resp["17524"]["thermal"][0].startswith("https")


@pytest.mark.realserver
def test_mosaic_block_visit_tiff_metadata():
    resp = wc.MosaicBlockVisit.tiff_metadata(20000, "stack")
    assert resp == {
        "camera_key": "stack",
        "camsys_id": 44,
        "date": "2018-08-27",
        "farm_id": 10438,
        "farm_name": "Black Jack",
        "flight_id": 5559,
        "subfield_id": "I",
        "bands": [
            {
                "band_number": 0,
                "description": "vnir800",
                "metadata": {"cam_id": 166},
                "unit_type": "DN",
            },
            {
                "band_number": 1,
                "description": "vnir670",
                "metadata": {"cam_id": 165},
                "unit_type": "DN",
            },
            {
                "band_number": 2,
                "description": "vnir550",
                "metadata": {"cam_id": 168},
                "unit_type": "DN",
            },
            {
                "band_number": 3,
                "description": "vnir700",
                "metadata": {"cam_id": 167},
                "unit_type": "DN",
            },
        ],
    }

    resp = wc.MosaicBlockVisit.tiff_metadata(20000, "thermal")
    assert resp == {
        "camera_key": "jenoptik",
        "camsys_id": 44,
        "date": "2018-08-27",
        "farm_id": 10438,
        "farm_name": "Black Jack",
        "flight_id": 5559,
        "image_type": "Jenoptik",
        "subfield_id": "I",
        "bands": [
            {
                "band_number": 0,
                "description": "thermal",
                "metadata": {"cam_id": 170},
                "unit_type": "DN",
            }
        ],
    }


def test_mbv_get_camera_images():
    with requests_mock.Mocker() as m:
        mock = m.get(
            wc.api_base
            + "/api/mosaic_block_visit/1232/get_camera_images/?camera_key=ids7000&format=json",
            json={"imu": "none.txt", "images": ["none.tif"]},
        )
        res = wc.MosaicBlockVisit.get_camera_images(1232, "ids7000")
        assert mock.called_once
        assert res == {"imu": "none.txt", "images": ["none.tif"]}


def test_mbv_get_camera_images_file_not_found():
    with requests_mock.Mocker() as m:
        mock = m.get(
            wc.api_base
            + "/api/mosaic_block_visit/1232/get_camera_images/?camera_key=ids7000&format=json",
            json={"error": "file not found", "file": "fake.tif"},
        )
        with pytest.raises(FileNotFoundError):
            wc.MosaicBlockVisit.get_camera_images(1232, "ids7000")
        assert mock.called_once
