import datetime
import json

import pytest
import responses
import worksclient as wc

SENSOR_READING_DATA = {
    "sensor_reading": {
        "id": 1,
        "variable": "NDVI",
        "value": 4.3,
        "created_at": datetime.datetime(2021, 1, 1, 1).isoformat(),
    }
}


@responses.activate
def test_sensor_reading_retrieve():
    responses.add(
        responses.GET,
        wc.api_base + "/api/sensor_readings/1/?format=json",
        json=SENSOR_READING_DATA,
        status=200,
        match_querystring=True,
    )
    response = wc.SensorReading.retrieve(1)
    assert response["sensor_reading"]["value"] == 4.3


@responses.activate
def test_sensor_reading_create():
    responses.add(
        responses.POST,
        wc.api_base + "/api/sensor_readings/",
        json=SENSOR_READING_DATA,
        status=200,
        match_querystring=True,
    )

    response = wc.SensorReading.create(SENSOR_READING_DATA)
    assert json.loads(responses.calls[0].request.body) == SENSOR_READING_DATA


@responses.activate
def test_sensor_reading_update():
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/sensor_readings/1/",
        json=SENSOR_READING_DATA,
        status=200,
        match_querystring=True,
    )

    update_data = {"value": 100}
    response = wc.SensorReading.update(1, update_data)
    assert response == SENSOR_READING_DATA
    assert json.loads(responses.calls[0].request.body) == update_data


@responses.activate
def test_sensor_reading_list_page_one():
    responses.add(
        responses.GET,
        wc.api_base + "/api/sensor_readings/?format=json&page=1",
        json={
            "sensor_readings": [{"id": 1}, {"id": 2}],
            "meta": {"total_pages": 2, "page": 1},
        },
        status=200,
        match_querystring=True,
    )

    response = wc.SensorReading.list(page=1)
    assert response == {
        "sensor_readings": [{"id": 1}, {"id": 2}],
        "meta": {"total_pages": 2, "page": 1},
    }


@responses.activate
def test_sensor_reading_list_page_two():
    responses.add(
        responses.GET,
        wc.api_base + "/api/sensor_readings/?format=json&page=2",
        json={
            "sensor_readings": [{"id": 3}, {"id": 4}],
            "meta": {"total_pages": 2, "page": 2},
        },
        status=200,
        match_querystring=True,
    )

    response = wc.SensorReading.list(page=2)
    assert response == {
        "sensor_readings": [{"id": 3}, {"id": 4}],
        "meta": {"total_pages": 2, "page": 2},
    }


@responses.activate
def test_sensor_reading_delete():
    sensor_reading_id = 3
    responses.add(
        responses.DELETE,
        wc.api_base + "/api/sensor_readings/{}/".format(sensor_reading_id),
        json={},
        status=200,
        match_querystring=True,
    )

    resp = wc.SensorReading.delete(sensor_reading_id)
    assert resp == {}
