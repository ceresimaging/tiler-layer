import responses

import worksclient as wc

sample_response = {
    "id": "ad50d3a9-8af9-4742-8d79-05f35101ddff",
    "name": "Hazelnut",
    "group": "Trees",
    "minimum_resolution": 1,
    "minimum_pixels": 4,
}


@responses.activate
def test_crop_detail_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/crop_details/?format=json",
        json=[sample_response],
        status=200,
        match_querystring=True,
    )

    resp = wc.CropDetail.list()
    assert len(resp) == 1
    assert resp[0]["name"] == "Hazelnut"
    assert resp[0]["group"] == "Trees"


@responses.activate
def test_crop_detail_retrieve():
    cd_id = "ad50d3a9-8af9-4742-8d79-05f35101ddff"
    responses.add(
        responses.GET,
        wc.api_base + "/api/crop_details/{}/?format=json".format(cd_id),
        json=[sample_response],
        status=200,
        match_querystring=True,
    )

    resp = wc.CropDetail.retrieve(cd_id)
    assert len(resp) == 1
    assert resp[0]["name"] == "Hazelnut"
    assert resp[0]["group"] == "Trees"
