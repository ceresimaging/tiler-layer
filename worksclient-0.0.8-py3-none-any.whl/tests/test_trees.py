import responses
import worksclient as wc


@responses.activate
def test_tree_retrieve():
    responses.add(
        responses.GET,
        wc.api_base
        + "/api/overlays/?source=tree_count&field_id=1&ordering=-created_at&format=json",
        json={"count": 1, "results": [{"id": 1, "visit": 1}]},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/trees/overlay/1/?format=json&page=1&ids_only=False",
        json=[
            [
                "id",
                {"type": "Point", "coordinates": [1, 2]},
                "Unknown",
                True,
                1,
                2,
                True,
                False,
            ]
        ],
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/trees/overlay/1/?format=json&page=2&ids_only=False",
        json=[],
        status=200,
        match_querystring=True,
    )

    expected = {
        "type": "FeatureCollection",
        "crs": {"type": "name", "properties": {"name": "EPSG:4326"}},
        "features": [
            {
                "type": "Feature",
                "id": "id",
                "geometry": {"type": "Point", "coordinates": [1, 2]},
                "properties": {
                    "varietal": "Unknown",
                    "is_present": True,
                    "plant_number": 2,
                    "row_number": 1,
                    "on_edge": True,
                    "on_boundary": False,
                },
            }
        ],
    }

    resp = wc.Tree.retrieve(1)
    assert expected == resp


@responses.activate
def test_create():
    trees = {
        "features": [
            {"properties": {}, "geometry": {"coordinates": []}},
            {"properties": {}, "geometry": {"coordinates": []}},
            {"properties": {}, "geometry": {"coordinates": []}},
        ]
    }
    missing_trees = {
        "features": [
            {"properties": {}, "geometry": {"coordinates": []}},
            {"properties": {}, "geometry": {"coordinates": []}},
            {"properties": {}, "geometry": {"coordinates": []}},
        ]
    }
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/1/?format=json",
        json={"id": 1, "receiving": False},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/?format=json&visit_id=1&source=tree_count",
        json={"results": [{"id": 1}]},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.DELETE,
        wc.api_base + "/api/trees/data/format=json",
        json={"status_code": 204},
        status=200,
        match_querystring=True,
    )

    responses.add(
        responses.POST,
        wc.api_base + "/api/trees/overlay/1/?format=json",
        json={"status_code": 201},
        status=201,
        match_querystring=True,
    )

    wc.Tree.FEATURES_PER_PAGE = 2
    resp = wc.Tree.create(1, trees, missing_trees)
    assert resp


@responses.activate
def test_update_varietals():
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/?format=json&visit_id=1&source=tree_count",
        json={"results": [{"id": 1}]},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/1/?format=json",
        json={"visit": 1},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.PATCH,
        wc.api_base + "/api/trees/overlay/1/?format=json",
        json={"status_code": 201},
        status=201,
        match_querystring=True,
    )

    resp = wc.Tree.update_varietals(
        1,
        [
            ["c25efea0-5949-46fe-aaf9-98982c39b6dd", "Padre"],
            ["8120ab3c-e18c-4ecf-97cd-795ad17f8a2e", "Butte"],
        ],
    )
    assert resp


@responses.activate
def test_create_fail():
    trees = {
        "features": [
            {"properties": {}, "geometry": {"coordinates": []}},
            {"properties": {}, "geometry": {"coordinates": []}},
            {"properties": {}, "geometry": {"coordinates": []}},
        ]
    }
    missing_trees = None
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/1/?format=json",
        json={"id": 1, "receiving": False},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/?format=json&visit_id=1&source=tree_count",
        json={"results": [{"id": 1}]},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/",
        json={"status_code": 500},
        status=500,
        match_querystring=True,
    )
    responses.add(
        responses.POST,
        wc.api_base + "/api/trees/overlay/1/?format=json",
        json={"status_code": 500},
        status=500,
        match_querystring=True,
    )

    wc.Tree.FEATURES_PER_PAGE = 2
    resp = wc.Tree.create(1, trees, missing_trees, delete=False)
    assert not resp


@responses.activate
def test_insert_data():
    responses.add(
        responses.GET,
        wc.api_base + "/api/overlays/1/?format=json",
        json={"id": 1, "receiving": False},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base
        + "/api/overlays/?format=json&visit_id=1&source=tree_data&overlay_type=water_stress",
        json={"results": [{"id": 1, "receiving": False}]},
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.DELETE,
        wc.api_base + "/api/overlays/1/",
        json={"status_code": 200},
        status=200,
        match_querystring=True,
    )

    responses.add(
        responses.POST,
        wc.api_base + "/api/trees/data/1/?format=json",
        json={"status_code": 201},
        status=201,
        match_querystring=True,
    )

    resp = wc.Tree.insert_data(1, "water_stress", [], delete=False)
    assert resp
