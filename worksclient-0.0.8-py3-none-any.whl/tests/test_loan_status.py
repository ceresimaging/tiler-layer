import responses

import worksclient as wc


payload = {
    "customer_id": "fake_id",
    "status": "processing_complete",  # Works `Loan` model status`
    "578": {
        "bucket": "fake_bucket_578",
        "key": "fake_key_578",
    },
    "soi": {
        "bucket": "fake_bucket_soi",
        "key": "fake_key_soi",
    },
}


@responses.activate
def test_loan_status_update():
    responses.add(
        responses.POST,
        wc.api_base + "/api/insurance/loans/digitization/status/",
        json=payload,
        status=200,
    )

    resp = wc.Loan.update_digitization_status(payload)
    assert resp == payload
