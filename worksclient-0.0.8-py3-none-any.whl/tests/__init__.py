import worksclient as wc
from worksclient import auth
import os

wc.api_base = os.environ.get("CERES_WORKS_URL", "http://localhost:8000")
# wc.api_base = 'http://works.ceresimaging.net'
try:
    wc.auth_token = auth.get_auth_token("guest", "ceres123")
except:
    print("setting the auth token failed with real server")

print("test setup loaded")
