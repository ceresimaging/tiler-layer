import pytest
import worksclient as wc
import requests_mock


@pytest.mark.realserver
def test_flight_retrieval_from_real_server():
    """
    Test that the Works server returns a real Flight when one is requested.
    :return:
    """
    resp = wc.Flight.retrieve(1907)
    assert type(resp) is dict
    assert resp["plan_geojson"]["id"] == 1907


@pytest.mark.realserver
def test_flight_list_date_cam():
    resp = wc.Flight.list(date="2018-06-27", cam_system=40)
    assert len(resp) == 1
    assert resp[0]["id"] == 4815


@pytest.mark.realserver
def test_flight_list_daterange():
    resp = wc.Flight.list(min_date="2018-06-29", max_date="2018-06-29")
    assert 4906 in [x["id"] for x in resp]


def test_flight_list_date_daterange():
    with pytest.raises(Exception):
        wc.Flight.list(date="2018-10-01", min_date="2018-10-01")


def test_flight_list_typechecking():
    with pytest.raises(TypeError):
        wc.Flight.list(date=2)
    with pytest.raises(TypeError):
        wc.Flight.list(cam_system="One")


def test_flight_list_dateformat():
    with pytest.raises(ValueError):
        wc.Flight.list(date="20-10-1000")
    with pytest.raises(ValueError):
        wc.Flight.list(date="2000_10_10")


def test_flight_list_exclude():
    with requests_mock.Mocker() as m:
        url_exclude = (
            wc.api_base
            + "/api/flights/?exclude_status_names=Failed+-+Hardware%2CFailed+-+Pilot%2CFailed+-+Other%2CFailed+-+Weather%2CFailed+-+Did+Not+Cover%2CCanceled"
        )
        flight_adapter = m.get(url_exclude, json="[{objects: 1}]")
        wc.Flight.list(exclude_cancelled=True)
        assert flight_adapter.call_count == 1

        url_no_exclude = wc.api_base + "/api/flights/"
        flight_adapter2 = m.get(url_no_exclude, json="[{objects: 1}]")
        wc.Flight.list()
        assert flight_adapter.call_count == 1
        assert flight_adapter2.call_count == 1


def test_flight_datetime_filtering():
    with requests_mock.Mocker() as m:
        url_gte = wc.api_base + "/api/flights/?flight_time_utc__gte=2010-10-2T00:00:00"
        flight_adapter = m.get(url_gte, json="[{objects: 1}]")
        wc.Flight.list(flight_time_utc__gte="2010-10-2T00:00:00")
        assert flight_adapter.call_count == 1
        url_lt = wc.api_base + "/api/flights/?flight_time_utc__lt=2010-10-2T00:00:00"
        flight_adapter2 = m.get(url_lt, json="[{objects: 1}]")
        wc.Flight.list(flight_time_utc__lt="2010-10-2T00:00:00")
        assert flight_adapter2.call_count == 1


def test_flight_update():
    with requests_mock.Mocker() as m:
        flight_adapter = m.patch(
            wc.api_base + "/api/flights/1/?format=json", json="[{objects: 1}]"
        )
        wc.Flight.update(1, {"duration": "1.337"})
        assert flight_adapter.call_count == 1


def test_status_update():
    with requests_mock.Mocker() as m:
        api_adapter = m.post(
            wc.api_base + "/api/flights/1/change_status/", json="[{objects: 1}]"
        )
        wc.Flight.change_status(1, wc.Flight.Status.COMPLETE)
        assert api_adapter.last_request.json() == {"new_status_name": "Complete"}
        assert api_adapter.call_count == 1


def test_get_processlogs_by_flight_id():
    with requests_mock.Mocker() as m:
        api_adapter = m.get(
            wc.api_base + "/api/process_log/?flight_id=123123",
            json="""[{'id': 800506,
                      'process_name': '',
                      'process_computer': '',
                      'time_started': '2021-01-22T06:33:26.837356-08:00',
                      'time_finished': None,
                      'time_alive': '2021-01-22T06:33:26.837356-08:00',
                      'duration_seconds': None,
                      'result': None,
                      'exception': None,
                      'heartbeat_interval': 0,
                      'flight': 12666,
                      'visit': None,
                      'mosaic_block_visit': None}]""",
        )
        wc.FlightProcessingEvent.get_by_flight_id(123123)
        assert api_adapter.call_count == 1
