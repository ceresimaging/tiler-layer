import requests_mock
import json
import pytest

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
except ImportError:
    # python 2.7
    from SimpleHTTPServer import SimpleHTTPRequestHandler as BaseHTTPRequestHandler
    from SocketServer import TCPServer as HTTPServer
from contextlib import contextmanager
import socket
from threading import Thread
import worksclient as wc


def mockserverrequesthandler_builder(response_data):
    class MockServerRequestHandler(BaseHTTPRequestHandler):
        _response_data = response_data

        def do_GET(self):
            """Sends response with the status code and json body from self._response_data"""
            resp = self._response_data.pop(0)
            code = resp["status_code"]
            body = json.dumps(resp["json"])
            self.send_response(code=code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body.encode("utf_8"))

    return MockServerRequestHandler


@contextmanager
def mock_server(response_dicts):
    """Context manager that creates and tears down a server that returns response_dict responses."""
    mock_server_port = _get_free_port()
    url = "http://localhost:{}".format(mock_server_port)
    handler = mockserverrequesthandler_builder(response_dicts)
    mock_server = HTTPServer(("localhost", mock_server_port), handler)
    mock_server_thread = Thread(target=mock_server.serve_forever)
    mock_server_thread.start()
    yield url
    mock_server.shutdown()
    mock_server_thread.join()


def _get_free_port():
    s = socket.socket(socket.AF_INET, type=socket.SOCK_STREAM)
    s.bind(("localhost", 0))
    address, port = s.getsockname()
    s.close()
    return port


def test_get():
    requester = wc.api_requestor.APIRequester()
    url = "{}/endpoint?value=1".format(requester.get_api_base())
    payload = {"payload": "value"}
    with requests_mock.Mocker() as m:
        m.get(url, json=payload)
        result = requester.get_request(url, {"value": 1})
    assert payload == result


def test_get_retry():
    expected = {"json": {"payload": "value"}, "status_code": 200}
    response_dicts = [
        {"json": {"error": "503"}, "status_code": 503},
        {"json": {"error": "502"}, "status_code": 502},
        {"json": {"error": "504"}, "status_code": 504},
        expected,
        {"json": {"error": "too_many_retries"}, "status_code": 504},
    ]
    wc.api_requestor.APIRequester.retries = len(response_dicts) - 1
    requester = wc.api_requestor.APIRequester()
    with mock_server(response_dicts) as url:
        result = requester.get_request(url, {"value": 2})
    assert result == expected["json"]


def test_get_retry_fail():
    response_dicts = [
        {"json": {"error": "503"}, "status_code": 503},
        {"json": {"error": "502"}, "status_code": 502},
        {"json": {"error": "expected"}, "status_code": 504},
        {"json": {"error": "too_many_retries"}, "status_code": 504},
    ]
    wc.api_requestor.APIRequester.retries = len(response_dicts) - 2
    requester = wc.api_requestor.APIRequester()
    with mock_server(response_dicts) as url:
        result = requester.get_request(url, {"value": 2})
    assert result == {"error": "expected"}


@pytest.mark.parametrize("status_code", [500, 400, 406, 403, 405])
def test_get_retry_non_retry_status(status_code):
    response_dicts = [
        {"json": {"expected": "response"}, "status_code": status_code},
        {"json": {"error": "retried unintentionally"}, "status_code": 502},
    ]
    wc.api_requestor.APIRequester.retries = 1
    requester = wc.api_requestor.APIRequester()
    with mock_server(response_dicts) as url:
        result = requester.get_request(url, {"value": 2})
    assert result == {"expected": "response"}
