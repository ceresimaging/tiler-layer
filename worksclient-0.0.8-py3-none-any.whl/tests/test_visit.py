import pytest
import responses
import requests_mock
import worksclient as wc
import datetime


print("wc.api_base", wc.api_base)


@responses.activate
def test_visit_retrieve():
    responses.add(
        responses.GET,
        wc.api_base + "/api/visits/1/?format=json",
        json={"test": "data"},
        status=200,
        match_querystring=True,
    )

    resp = wc.Visit.retrieve(1)
    assert resp["test"] == "data"


@responses.activate
def test_visit_list():
    responses.add(
        responses.GET,
        wc.api_base + "/api/visits/?format=json",
        json=[{"test": "data1"}, {"test": "data2"}],
        status=200,
        match_querystring=True,
    )

    resp = wc.Visit.list()
    assert len(resp) == 2
    assert resp[0]["test"] == "data1"
    assert resp[1]["test"] == "data2"


@responses.activate
def test_visit_date_filter():

    today = datetime.datetime.now().date()

    yesterday = today - datetime.timedelta(days=1)

    date_query = "flight_min_date={}&flight_max_date={}".format(
        yesterday.strftime("%Y-%m-%d"), today.strftime("%Y-%m-%d")
    )

    responses.add(
        responses.GET,
        wc.api_base + "/api/visits/?format=json&flight_id=123&{}".format(date_query),
        json=[{"test": "flight+field"}],
        status=200,
        match_querystring=True,
    )

    resp = wc.Visit.list(
        flight_id=123, flight_min_date=yesterday, flight_max_date=today
    )
    assert len(resp) == 1
    assert resp[0]["test"] == "flight+field"


@responses.activate
def test_visit_crop_detail_filter():

    test_crop = "test_crop_uuid"

    responses.add(
        responses.GET,
        wc.api_base + "/api/visits/?format=json&crop_detail_id={}".format(test_crop),
        json=[{"test": "crop filter"}],
        status=200,
        match_querystring=True,
    )

    resp = wc.Visit.list(crop_detail_id=test_crop)
    assert len(resp) == 1
    assert resp[0]["test"] == "crop filter"


@responses.activate
def test_visit_list_with_args():
    responses.add(
        responses.GET,
        wc.api_base + "/api/visits/?format=json&flight_id=123&field=456",
        json=[{"test": "flight+field"}],
        status=200,
        match_querystring=True,
    )
    responses.add(
        responses.GET,
        wc.api_base + "/api/visits/?format=json&flight_id=789",
        json=[{"test": "flight1"}, {"test": "flight2"}],
        status=200,
        match_querystring=True,
    )

    resp = wc.Visit.list(flight_id=123, field_id=456)
    assert len(resp) == 1
    assert resp[0]["test"] == "flight+field"

    resp = wc.Visit.list(flight_id=789)
    assert len(resp) == 2
    assert resp[0]["test"] == "flight1"
    assert resp[1]["test"] == "flight2"


def test_visit_update():
    with requests_mock.Mocker() as m:
        visit_adapter = m.patch(
            wc.api_base + "/api/visits/1/?format=json", json="[{objects: 1}]"
        )
        wc.Visit.update(1, {"altitude": "1234.5"})
        assert visit_adapter.call_count == 1


def test_status_update():
    with requests_mock.Mocker() as m:
        api_adapter = m.post(
            wc.api_base + "/api/visits/1/change_status/", json="[{objects: 1}]"
        )
        wc.Visit.change_status(1, wc.Visit.Status.UPLOADING)
        assert api_adapter.last_request.json() == {"new_status_name": "Uploading"}
        assert api_adapter.call_count == 1
