"""
Contains high-level interface with API, which is embodied in the `APIRequestor` type. This handles authorization,
HTTP GET/POST formatting, and error handling.
"""

import six.moves.urllib as urllib
import calendar
import requests
import time
import datetime
import json
import socket
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from worksclient import error, util, __version__


def _encode_datetime(dttime):
    if dttime.tzinfo and dttime.tzinfo.utcoffset(dttime) is not None:
        utc_timestamp = calendar.timegm(dttime.utctimetuple())
    else:
        utc_timestamp = time.mktime(dttime.timetuple())

    return int(utc_timestamp)


def _api_encode(data):
    for key, value in data.items():
        if value is None:
            continue
        elif isinstance(value, datetime.datetime):
            yield (key, _encode_datetime(value))
        else:
            yield (key, value)


def _build_api_url(url, query):
    scheme, netloc, path, base_query, fragment = urllib.parse.urlsplit(url)
    if base_query:
        query = str("%s&%s" % (base_query, query))

    return urllib.parse.urlunsplit((scheme, netloc, path, query, fragment))


class APIRequester(object):
    timeout_connect = 60.0  # android default
    timeout_read = 60.0
    retries = 20
    retry_backoff_factor = 0.3
    retry_statusforcelist = set(
        (
            502,  # bad gateway - during some deploys, not enough workers?
            503,  # service unavailable - during some deploys
            504,
        )
    )  # gateway timeout - not enough workers
    retry_method_whitelist = Retry.DEFAULT_METHOD_WHITELIST | {"POST"}

    def __init__(self, auth_token=None):
        self._auth_token = auth_token
        self.params = {"format": "json"}
        self._session = None

    def abs_url(self, url):
        return urllib.parse.urljoin(self.get_api_base(), url)

    @property
    def auth_token(self):
        if self._auth_token:
            return self.auth_token
        else:
            from worksclient import auth_token

            return auth_token

    @auth_token.setter
    def auth_token(self, value):
        self._auth_token = value

    def _build_auth_header(self, auth_token=None, headers=None):
        headers = headers or {}

        my_auth_token = auth_token or self.auth_token

        auth_header = {"Authorization": "Token {}".format(my_auth_token)}
        headers.update(auth_header)
        return headers

    def _get_timeout(self, connect=None, read=None):
        """
        Generates timeout parameter for requests.

        Parameters
        ----------
        connect : float or None
        read: float or None

        Returns
        -------
        tuple[float, float]
            connection timeout (sec), read timeout (sec)
        """
        connect = connect or self.timeout_connect
        read = read or self.timeout_read
        return connect, read

    def get_api_base(
        self,
    ):
        from worksclient import api_base

        return api_base

    def get_session(self):
        """
        Context manager to that yields session with provided or default retry parameters. Closes session on
        exit.

        Parameters
        ----------
        retries : int
            Number of retries to attempt.
        backoff_factor = float
            Backoff factor in seconds. On each retry is calculated using this
            factor multiplied by (2 ** retry_iteration)

        Yields
        ------
        requests.Session
        """

        if self._session is None:
            retry = Retry(
                total=self.retries,
                read=self.retries,
                connect=self.retries,
                status=self.retries,
                redirect=self.retries,
                backoff_factor=self.retry_backoff_factor,
                status_forcelist=self.retry_statusforcelist,
                raise_on_status=False,
                method_whitelist=self.retry_method_whitelist,
            )
            self._session = requests.Session()
            self._session.mount("http://", HTTPAdapter(max_retries=retry))
            self._session.mount("https://", HTTPAdapter(max_retries=retry))

            # set headers
            client_header = {
                "X-Client-Hostname": socket.gethostname(),
                "X-Worksclient-Version": __version__,
            }
            self._session.headers.update(self._build_auth_header())
            self._session.headers.update(client_header)
        return self._session

    def get_request(
        self,
        url,
        params=None,
        supplied_headers=None,
        format="json",
        timeout_connect=None,
        timeout_read=None,
        raise_for_status=False,
    ):
        """

        Parameters
        ----------
        url : str
        params : dict
        supplied_headers : dict
        format : str
        timeout_connect : float or None
            Time in sec to timeout if no connection established. Class default is 1 sec.
        timeout_read : float or None
            Time in sec to timeout if no bytes recieved on response. Class default is 10 sec.
        raise_for_status: bool
            If true, raise for status != 200
        Returns
        -------

        """
        params = params or {}

        # combine default params and given params
        params_all = {}
        params_all.update(self.params)
        params_all.update(params)
        timeout = self._get_timeout(timeout_connect, timeout_read)
        abs_url = self.abs_url(url)
        encoded_params = urllib.parse.urlencode(list(_api_encode(params_all)))
        abs_url = _build_api_url(abs_url, encoded_params)
        resp = self.get_session().get(
            abs_url, timeout=timeout, headers=supplied_headers
        )
        if raise_for_status:
            resp.raise_for_status()
        return self._parse_get(resp, format)

    def _parse_get(self, response, format):
        if format == "json":
            return self.get_safe_json_response(response)
        elif format == "text":
            return response.text

    def post_request(
        self,
        url,
        data,
        params=None,
        supplied_headers=None,
        files=None,
        timeout_connect=None,
        timeout_read=None,
    ):
        """

        Parameters
        ----------
        url : str
        data
        params : dict
        supplied_headers : dict
        files
        timeout_connect : float or None
            Time in sec to timeout if no connection established. Class default is 1 sec.
        timeout_read : float or None
            Time in sec to timeout if no bytes recieved on response. Class default is 10 sec.


        Returns
        -------

        """
        abs_url = self.abs_url(url)
        encoded_params = urllib.parse.urlencode(list(_api_encode(params or {})))
        abs_url = _build_api_url(abs_url, encoded_params)
        timeout = self._get_timeout(timeout_connect, timeout_read)
        if files is None:
            resp = self.get_session().post(
                abs_url, json=data, timeout=timeout, headers=supplied_headers
            )
        else:
            resp = self.get_session().post(
                abs_url,
                data=data,
                files=files,
                timeout=timeout,
                headers=supplied_headers,
            )
        return self.get_safe_json_response(resp)

    def post_file_request(
        self,
        url,
        files,
        params=None,
        supplied_headers=None,
        timeout_connect=None,
        timeout_read=None,
    ):
        """

        Parameters
        ----------
        url : str
        files
        params : dict
        supplied_headers : dict
        timeout_connect : float or None
            Time in sec to timeout if no connection established. Class default is 1 sec.
        timeout_read : float or None
            Time in sec to timeout if no bytes recieved on response. Class default is 10 sec.
        Returns
        -------

        """
        timeout = self._get_timeout(timeout_connect, timeout_read)
        abs_url = self.abs_url(url)
        encoded_params = urllib.parse.urlencode(list(_api_encode(params or {})))
        abs_url = _build_api_url(abs_url, encoded_params)
        resp = self.get_session().post(
            abs_url, headers=supplied_headers, files=files, timeout=timeout
        )
        return self.get_safe_json_response(resp)

    def patch_request(
        self,
        url,
        data,
        params=None,
        supplied_headers=None,
        files=None,
        timeout_connect=None,
        timeout_read=None,
    ):
        """

        Parameters
        ----------
        url : str
        data
        params : dict
        supplied_headers : dict
        files
        timeout_connect : float or None
            Time in sec to timeout if no connection established. Class default is 1 sec.
        timeout_read : float or None
            Time in sec to timeout if no bytes recieved on response. Class default is 10 sec.s

        Returns
        -------

        """
        timeout = self._get_timeout(timeout_connect, timeout_read)
        abs_url = self.abs_url(url)
        encoded_params = urllib.parse.urlencode(list(_api_encode(params or {})))
        abs_url = _build_api_url(abs_url, encoded_params)
        resp = self.get_session().patch(
            abs_url, json=data, headers=supplied_headers, files=files, timeout=timeout
        )
        return self.get_safe_json_response(resp)

    def delete_request(
        self,
        url,
        data=None,
        params=None,
        supplied_headers=None,
        files=None,
        timeout_connect=None,
        timeout_read=None,
    ):
        """

        Parameters
        ----------
        url : str
        data
        params : dict
        supplied_headers : dict
        files
        timeout_connect : float or None
            Time in sec to timeout if no connection established. Class default is 1 sec.
        timeout_read : float or None
            Time in sec to timeout if no bytes recieved on response. Class default is 10 sec.


        Returns
        -------

        """
        abs_url = self.abs_url(url)
        encoded_params = urllib.parse.urlencode(list(_api_encode(params or {})))
        abs_url = _build_api_url(abs_url, encoded_params)
        timeout = self._get_timeout(timeout_connect, timeout_read)
        if files is None:
            resp = self.get_session().delete(
                abs_url, json=data, timeout=timeout, headers=supplied_headers
            )
        else:
            resp = self.get_session().delete(
                abs_url,
                data=data,
                files=files,
                timeout=timeout,
                headers=supplied_headers,
            )
        return self.get_safe_json_response(resp)

    def get_safe_json_response(self, response):
        """
        Get the response safely and show errors if it fails.
        """
        try:
            json_data = json.loads(response.text)
        except ValueError as e:
            try:
                if response.status_code == 404:
                    print("404 error, check your url. {}".format(response.url))
                    return
                elif response.status_code in (201, 204, 422):
                    return {"status_code": response.status_code}
                else:
                    print("status_code: {}".format(response.status_code))
            except:
                pass
            print("JSON decoding error.")
            print("response text:")
            print(response.text)
            print(e)
            return

        return json_data

    def handle_error_response(self, rbody, rcode, resp, rheaders):
        try:
            error_data = resp["error"]
        except (KeyError, TypeError):
            raise error.APIError(
                "Invalid response object from API: %r (HTTP response code "
                "was %d)" % (rbody, rcode),
                rbody,
                rcode,
                resp,
            )

    def interpret_response(self, rbody, rcode, rheaders):
        try:
            if hasattr(rbody, "decode"):
                rbody = rbody.decode("utf-8")
            resp = util.json.loads(rbody)
        except Exception:
            raise error.APIError(
                "Invalid response body from API: %s "
                "(HTTP response code was %d)" % (rbody, rcode),
                rbody,
                rcode,
                rheaders,
            )
        if not (200 <= rcode < 300):
            self.handle_error_response(rbody, rcode, resp, rheaders)
        return resp


class LicenseAPIRequestor(APIRequester):
    """API requestor that uses license url instead of base"""

    def get_api_base(
        self,
    ):
        from worksclient import license_api_base

        return license_api_base
