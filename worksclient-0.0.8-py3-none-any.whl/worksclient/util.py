from functools import wraps
import json
import logging

import worksclient

LOGGER = logging.getLogger(__name__)


def _console_log_level():
    if worksclient.log in ["debug", "info"]:
        return worksclient.log
    else:
        return None


def show_errors(func):
    """
    request.raise_for_status() does not show the response body
    which makes debugging sisyphean.
    """
    import requests
    from pprint import pformat

    def handler(*args, **kwargs):
        try:
            response = func(*args, **kwargs)
        except requests.exceptions.HTTPError as error:
            try:
                # pylint: disable=anomalous-backslash-in-string
                msg = """
********************************************************************************
********************************************************************************


    __________  ____  ____  ____
   / ____/ __ \/ __ \/ __ \/ __ |
  / __/ / /_/ / /_/ / / / / /_/ /
 / /___/ _, _/ _, _/ /_/ / _, _/
/_____/_/ |_/_/ |_|\____/_/ |_|


...but don't worry, we caught it!

{}

********************************************************************************
********************************************************************************
                """.format(
                    pformat(error.response.json())
                )
                LOGGER.error(msg)
            except json.decoder.JSONDecodeError:
                # pylint: disable=anomalous-backslash-in-string
                msg = """
********************************************************************************
********************************************************************************

    ____  ___    ____     __________  ____  ____  ____
   / __ )/   |  / __ \   / ____/ __ \/ __ \/ __ \/ __ |
  / __  / /| | / / / /  / __/ / /_/ / /_/ / / / / /_/ /
 / /_/ / ___ |/ /_/ /  / /___/ _, _/ _, _/ /_/ / _, _/
/_____/_/  |_/_____/  /_____/_/ |_/_/ |_|\____/_/ |_|


...and we don't know what to do about it :(

Ceres Works returned: {}

********************************************************************************
********************************************************************************
                """.format(
                    error.response.text
                )
                LOGGER.error(msg)

            raise requests.exceptions.HTTPError(error)
        return response

    return handler


def parse_sort(func):
    """
    Decorator to parse `include` kwarg to wc Resources into `params`
    """

    @wraps(func)
    def sort_wrapper(*args, **kwargs):
        requestor = args[0]

        kwargs.setdefault("params", {})

        sort_opts = requestor.OPTIONS["sort"]

        if "sort" in kwargs.keys():
            sort = kwargs.get("sort")

            registered = any(sort.lstrip("-").startswith(opt) for opt in sort_opts)
            if not registered:
                class_ = type(requestor).__name__
                msg = (
                    "Invalid sort {} not whitelisted in wc.v2.{}.OPTIONS. "
                    "Available sorts are {}".format(
                        sort.split(".")[0], class_, sort_opts
                    )
                )
                raise NotImplementedError(msg)

            kwargs["params"]["sort[]"] = sort

        return func(*args, **kwargs)

    return sort_wrapper


def parse_includes(func):
    """
    Decorator to parse `include` kwarg to wc Resources into `params`
    """

    @wraps(func)
    def include_wrapper(*args, **kwargs):
        requestor = args[0]

        kwargs.setdefault("params", {})

        include_opts = requestor.OPTIONS["include"]

        if "include" in kwargs.keys():
            includes = kwargs.get("include")

            kwargs["params"].setdefault("include[]", [])
            for inc in includes:

                registered = any(inc.startswith(io) for io in include_opts)
                if not registered:
                    class_ = type(requestor).__name__
                    msg = (
                        "Invalid include {} not whitelisted in wc.v2.{}.OPTIONS. "
                        "Available includes are {}".format(
                            inc.split(".")[0], class_, include_opts
                        )
                    )
                    raise NotImplementedError(msg)

                inc_string = "{}.".format(inc)  # append a dot
                kwargs["params"]["include[]"].append(inc_string)

        return func(*args, **kwargs)

    return include_wrapper


def parse_filters(func):
    """
    Decorator to parse `filters` kwarg to wc Resources into `params`
    """

    @wraps(func)
    def filters_wrapper(*args, **kwargs):
        requestor = args[0]

        kwargs.setdefault("params", {})

        filter_opts = requestor.OPTIONS["filters"]

        if "filters" in kwargs.keys():
            filters = kwargs.get("filters")

            for key, value in filters.items():
                # Check to see if it's allowed
                registered = any(key.startswith(f) for f in filter_opts)
                if not registered:
                    class_ = type(requestor).__name__
                    msg = (
                        "Invalid filter {} not whitelisted in wc.v2.{}.OPTIONS. "
                        "Available filters are {}".format(
                            key.split(".")[0], class_, filter_opts
                        )
                    )
                    raise NotImplementedError(msg)

                if key in requestor.filter_passthrough:
                    kwargs["params"][key] = value
                else:
                    kwargs["params"]["filter{{{}}}".format(key)] = value

        return func(*args, **kwargs)

    return filters_wrapper
