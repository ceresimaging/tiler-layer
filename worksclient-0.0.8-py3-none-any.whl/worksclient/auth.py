import requests
import json

import worksclient as wc


def get_auth_token(username, password, verbose=True, timeout=60.0):
    if verbose:
        print("logging in")
    credentials = {"username": username, "password": password}
    resp = requests.post(
        wc.api_base + "/api/login/?format=json", credentials, timeout=timeout
    )
    if resp.status_code == 200:
        token = resp.json()["token"]
    else:
        raise ValueError("Could not get auth token. Check your username and password")
    return token
