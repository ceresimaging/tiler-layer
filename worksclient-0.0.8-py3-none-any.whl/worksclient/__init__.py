from .__version__ import __version__

import os
import logging

auth_token = None
api_base = os.environ.get("CERES_WORKS_URL", "https://works.ceresimaging.net")
license_api_base = os.environ.get(
    "CERES_LICENSE_URL", "https://licenses.ceresimaging.net"
)
from worksclient.v2 import resource as resource_v2


from .auth import get_auth_token

from worksclient import resource

LOGGER = logging.getLogger(__name__)

DEBUG = False

Auth = resource.Auth()
BlockCandidateGenerationEvent = resource.BlockCandidateGenerationEvent()
BlockCandidateSelectionEvent = resource.BlockCandidateSelectionEvent()
BlockMosaicEvent = resource.BlockMosaicEvent()
BlockProcessingEvent = resource.BlockProcessingEvent()
BlockRegistrationEvent = resource.BlockRegistrationEvent()
BlockStackEvent = resource.BlockStackEvent()
BlockUploadEvent = resource.BlockUploadEvent()
BaseGrid = resource.BaseGrid()
Cam = resource.Cam()
CamCalibration = resource.CamCalibration()
CamSystem = resource.CamSystem()
CropDetail = resource.CropDetail()
Customer = resource.Customer()
CustomLayer = resource.CustomLayer()
DisplayField = resource.DisplayField()
FDFPath = resource.FDFPath()
Farm = resource.Farm()
Field = resource.Field()
FieldRank = resource.FieldRank()
Flight = resource.Flight()
FlightCamCorrections = resource.FlightCamCorrections()
FlightPreprocessCameraTransferEvent = resource.FlightPreprocessCameraTransferEvent()
FlightPreprocessUploadingEvent = resource.FlightPreprocessUploadingEvent()
FlightPreprocessWaitingEvent = resource.FlightPreprocessWaitingEvent()
FlightPreprocessingEvent = resource.FlightPreprocessingEvent()
FlightProcessingEvent = resource.FlightProcessingEvent()
FlightILATiePoints = resource.FlightILATiePoints()
FlyingService = resource.FlyingService()
Grid = resource.Grid()
ILATiePoint = resource.ILATiePoint()
ImageSelectionFootprint = resource.ImageSelectionFootprint()
Loan = resource.Loan()
Marker = resource.Marker()
MosaicBlockVisit = resource.MosaicBlockVisit()
Overlay = resource.Overlay()
Pilot = resource.Pilot()
Pinterface = resource.Pinterface()
ProductComponent = resource.ProductComponent()
QuantitativeData = resource.QuantitativeData()
QuantitativeDataType = resource.QuantitativeDataType()
RMADate = resource.RMADate()
Satellite = resource.Satellite()
SensorReading = resource.SensorReading()
SensorDevice = resource.SensorDevice()
Tree = resource.Tree()
UserSettings = resource.UserSettings()
Visit = resource.Visit()
VisitProcessingEvent = resource.VisitProcessingEvent()
VisitReadyToStackEvent = resource.VisitReadyToStackEvent()


class v2:
    Visit = resource_v2.Visit()
    Flight = resource_v2.Flight()
    Field = resource_v2.Field()
    FlyingService = resource_v2.FlyingService()
    Pilot = resource_v2.Pilot()
    PilotSchedule = resource_v2.PilotSchedule()
    User = resource_v2.User()
    VisitWeather = resource_v2.VisitWeather()
    VisitStatistic = resource_v2.VisitStatistic()
    CropVarietal = resource_v2.CropVarietal()


CODE_PATH = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(os.path.dirname(CODE_PATH), "data")


"""
CONFIG
"""
from six.moves import configparser

config_dir = os.path.expanduser("~/.worksclient")
config_file = os.path.join(config_dir, "settings.ini")
config = configparser.ConfigParser()

try:
    config.read(config_file)
    auth_token = config["credentials"]["token"]
except:
    LOGGER.debug(
        "Couldn't find {} file. Setting config values from environment.".format(
            config_file
        )
    )
    auth_token = os.environ.get("WORKS_CLIENT_TOKEN")
    if auth_token is None:
        LOGGER.warning(
            "Works auth token not loaded from environment. Have you set $WORKS_CLIENT_TOKEN?\n"
            "You can get your token at https://works.ceresimaging.net/accounts/users/"
        )
