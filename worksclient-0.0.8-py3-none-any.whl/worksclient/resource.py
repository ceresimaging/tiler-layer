# -*- coding: utf-8 -*-

"""
Access to works fields api.
"""
import six.moves.urllib as urllib
from worksclient.api_requestor import APIRequester, LicenseAPIRequestor
import json
import socket
import re
import threading
import os
import errno
import sys

if sys.version_info.major < 3:
    FileNotFoundError = IOError

import six
from time import sleep

HOSTNAME = socket.gethostname()

if six.PY3:
    TimerClass = threading.Timer
else:
    TimerClass = threading._Timer


class WorksObject(dict):
    def __init__(self, auth_token=None, **params):
        super(WorksObject, self).__init__()

        object.__setattr__(self, "auth_token", auth_token)


class BaseResource(APIRequester):
    def __init__(self):
        super(BaseResource, self).__init__()

    def list(self, page=None):
        url = self.url
        params = None
        if page is not None:
            params = {"page": page}
        pilot_text = self.get_request(url, format="text", params=params)
        pilot_json = json.loads(pilot_text)
        try:
            next_url = pilot_json.get("next")
            params = dict()
        except AttributeError:
            # if the return value is a list, pagination is not applicable
            next_url = None
            # convert pilot_json to dict to match paginated values
            pilot_json = {"results": pilot_json}
        # if pagination is used, and page is None, iterate through each page and accumulate results in pilot_json
        while next_url is not None and page is None:
            sp = urllib.parse.urlsplit(next_url)
            params["page"] = sp.query.split("=")[-1]
            pilot_text = self.get_request(url, format="text", params=params)
            next_pilot_json = json.loads(pilot_text)
            next_url = next_pilot_json.get("next")
            pilot_json["results"] += next_pilot_json["results"]
        # only return the results
        return pilot_json["results"]

    def retrieve(self, id, format="json"):
        url = urllib.parse.urljoin(self.url, "{}/".format(id))
        params = {"format": "json"}
        resp_json = self.get_request(url, params, format=format)
        return resp_json


class Auth(BaseResource):
    url = "/api/token/email/"

    def change_token_for_email(self, email):
        import worksclient

        params = {"format": "json"}
        data = {"email": email}
        response = self.post_request(self.url, data, params)
        if response is not None:
            token = response.get("token")
            if token is not None:
                worksclient.auth_token = token
        return response


class Customer(BaseResource):
    url = "/api/customers/"

    def list(self, **kwargs):
        params = {"format": "json"}
        params.update(kwargs)
        return self.get_request(self.url, params)


class Pilot(BaseResource):
    url = "/api/pilots/"


class PilotSchedule(BaseResource):
    url = "/api/pilot_schedules/"


class CamCalibration(BaseResource):
    url = "/api/camcalibrations/"

    def create(
        self,
        cam=None,
        calibration_date=None,
        dark=None,
        gain=None,
        integration_time=None,
        offset=None,
        data_directory=None,
        note=None,
    ):
        data = {
            "cam": cam,
            "calibration_date": calibration_date.isoformat(),
            "dark": dark,
            "gain": gain,
            "offset": offset,
            "integration_time": integration_time,
            "data_directory": data_directory,
            "note": note,
        }
        resp = self.post_request(self.url, data, params={"format": "json"})
        return resp


class CropDetail(BaseResource):
    url = "/api/crop_details/"


class Marker(BaseResource):
    timeout_connect = 10
    timeout_read = 60
    retries = 3
    url = "/api/markers/"

    def list(self, page=None, query_params=None):
        if query_params is None:
            query_params = {}

        if page is not None:
            query_params["page"] = page

        resp = self.get_request(self.url, query_params)
        return resp

    def create(self, geojson):
        resp = self.post_request(self.url, geojson)
        return resp

    def delete(self, marker_id):
        url = urllib.parse.urljoin(self.url, "{}/".format(marker_id))
        resp = self.delete_request(url)
        return resp

    def update(self, marker_id, geojson):
        url = urllib.parse.urljoin(self.url, "{}/".format(marker_id))
        resp = self.patch_request(url, geojson)
        return resp

    def comments(self, marker_id):
        url = "{}{}/comments/".format(self.url, marker_id)
        resp = self.get_request(url)
        return resp


class SensorReading(BaseResource):
    timeout_connect = 10
    timeout_read = 60
    retries = 3
    url = "/api/sensor_readings/"

    def list(self, page=None, query_params=None):
        if query_params is None:
            query_params = {}

        if page is not None:
            query_params["page"] = page

        resp = self.get_request(self.url, query_params)
        return resp

    def create(self, payload):
        resp = self.post_request(self.url, payload)
        return resp

    def delete(self, sensor_reading_id):
        url = urllib.parse.urljoin(self.url, "{}/".format(sensor_reading_id))
        resp = self.delete_request(url)
        return resp

    def update(self, sensor_reading_id, geojson):
        url = urllib.parse.urljoin(self.url, "{}/".format(sensor_reading_id))
        resp = self.patch_request(url, geojson)
        return resp


class SensorDevice(BaseResource):
    timeout_connect = 10
    timeout_read = 60
    retries = 3
    url = "/api/sensor_devices/"

    def list(self, page=None, query_params=None):
        if query_params is None:
            query_params = {}

        if page is not None:
            query_params["page"] = page

        resp = self.get_request(self.url, query_params)
        return resp

    def create(self, geojson):
        resp = self.post_request(self.url, geojson)
        return resp

    def delete(self, sensor_reading_id):
        url = urllib.parse.urljoin(self.url, "{}/".format(sensor_reading_id))
        resp = self.delete_request(url)
        return resp

    def update(self, sensor_reading_id, geojson):
        url = urllib.parse.urljoin(self.url, "{}/".format(sensor_reading_id))
        resp = self.patch_request(url, geojson)
        return resp


class QuantitativeData(BaseResource):
    url = "/api/quant_data/"

    def create(self, data):
        resp = self.post_request(self.url, data)
        return resp


class Loan(BaseResource):
    url = "/api/insurance/loans/digitization/status/"

    def update_digitization_status(self, data):
        resp = self.post_request(self.url, data, params={"format": "json"})
        return resp


class QuantitativeDataType(BaseResource):
    url = "/api/quant_data/types/"

    def create(self, data):
        resp = self.post_request(self.url, data)
        return resp


class FDFPath(BaseResource):

    url = "/api/fdf_path/"

    def get(
        self,
        stage=None,
        flight_id=None,
        field_id=None,
        camera=None,
        mosaic_block_letter=None,
        parameter_set=None,
    ):

        if parameter_set == "default":
            parameter_set = None

        url = urllib.parse.urljoin(self.url, "{}/".format(stage))
        query = {
            "flight_id": flight_id,
            "field_id": field_id,
            "camera": camera,
            "mosaic_block_letter": mosaic_block_letter,
            "param_set": parameter_set,
        }
        params = {k: v for k, v in query.items() if v is not None}
        response = self.get_request(url, params=params)
        return response


class ImageSelectionFootprint(BaseResource):

    url = "/api/calc/image_selection_footprint/"

    def calculate(self, latitude=None, longitude=None, altitude=None, cam_id=None):
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "altitude": altitude,
            "cam_id": cam_id,
        }

        # remove None params, unpredictable serialization behavior is a liability
        payload = {k: v for k, v in params.items() if v is not None}

        response = self.post_request(self.url, data=payload)
        return response


class Visit(BaseResource):
    def __init__(self):
        super(Visit, self).__init__()
        self.url = "/api/visits/"

    class Status:
        PUBLISHED = "Published"
        PUBLISHED_PARTIAL = "Published (partial)"
        REGISTERED = "Registered"
        UPLOADING = "Uploading"
        PENDING_STACKING = "Pending Stacking (auto)"
        PENDING_MOSAICING = "Pending Mosaicing (auto)"
        FAILED_PILOT = "Failed - Pilot"
        FAILED_WEATHER = "Failed - Weather"
        FAILED_AIRSPACEISSUE = "Failed - Airspace Issue"
        FAILED_ARTIFACT = "Failed - Artifact"
        FAILED_COVERAGE = "Failed - Did Not Cover"
        FAILED_FLIGHTPLANNING = "Failed - Flight Planning"
        FAILED_OTHER = "Failed - Other"
        FAILED_PLANEISSUE = "Failed - Plane Issue"
        FAILED_RANOUTOFTIMEONFLIGHT = "Failed - Ran Out of Time on Flight"
        FAILED_SALES = "Failed - Sales"
        FAILED_HARDWARE = "Failed - Hardware"
        FAILED_TIMEOFDAY = "Failed - Time of Day"
        FAILED_WILDFIRE = "Failed - Wildfire"

    def list(self, **kwargs):
        params = {"format": "json"}
        if "field_id" in kwargs:
            field = kwargs["field_id"]
            del kwargs["field_id"]
            kwargs["field"] = field
        params.update(kwargs)

        return self.get_request(self.url, params)

    def update(self, id, changes):
        url = urllib.parse.urljoin(self.url, "{}/".format(id))
        resp = self.patch_request(url, changes, params={"format": "json"})
        return resp

    def change_status(self, id, new_status_name):
        url = urllib.parse.urljoin(self.url, "{}/change_status/".format(id))
        data = {"new_status_name": new_status_name}
        resp = self.post_request(url, data)
        return resp


class MosaicBlockVisit(BaseResource):
    url = "/api/mosaic_block_visit/"

    def create(self, flight_id, field_id, mosaic_block_letter):
        data = {
            "flight": flight_id,
            "field": field_id,
            "mosaic_block_letter": mosaic_block_letter,
        }
        resp = self.post_request(self.url, data, params={"format": "json"})
        return resp

    def get_registered(self, mbv_id, format="json", temp_url=False):
        """
        Get paths to registered images for this MBV.
        Parameters
        ----------
        mbv_id: int
        format: str
        temp_url: bool

        Returns
        -------

        """
        url = urllib.parse.urljoin(self.url, "{}/get_registered/".format(mbv_id))
        extra_params = dict()
        if temp_url:
            extra_params["temp_url"] = temp_url
        data = self.get_request(url, format=format, params=extra_params)
        return data

    def get_mosaic(self, mbv_id, format="json", temp_url=False):
        """
        Get paths to mosaic images for this MBV.
        Parameters
        ----------
        mbv_id: int
        format: str
        temp_url: bool

        Returns
        -------

        """
        url = urllib.parse.urljoin(self.url, "{}/get_mosaic/".format(mbv_id))
        extra_params = dict()
        if temp_url:
            extra_params["temp_url"] = temp_url
        data = self.get_request(url, format=format, params=extra_params)
        if "error" in data:
            if data["error"] == "file not found":
                raise FileNotFoundError(
                    errno.ENOENT, os.strerror(errno.ENOENT), data["file"]
                )
        return data

    def get_mosaic_inputs(self, mbv_id, camera_type, format="json"):
        url = urllib.parse.urljoin(self.url, "{}/get_mosaic_inputs/".format(mbv_id))
        data = self.get_request(url, format=format, params={"camera_type": camera_type})
        if "error" in data:
            if data["error"] == "file not found":
                raise FileNotFoundError(
                    errno.ENOENT, os.strerror(errno.ENOENT), data["file"]
                )
        return data

    def get_camera_images(self, mbv_id, camera_key, format="json"):
        """Gets raw camera images for a specified mosaic block and camera key (ie 'ids670' or 'jenoptik')"""
        url = urllib.parse.urljoin(self.url, "{}/get_camera_images/".format(mbv_id))
        data = self.get_request(url, format=format, params={"camera_key": camera_key})
        if "error" in data:
            if data["error"] == "file not found":
                raise FileNotFoundError(
                    errno.ENOENT, os.strerror(errno.ENOENT), data["file"]
                )
        return data

    def tiff_metadata(self, mbv_id, camera_key, format="json"):
        url = urllib.parse.urljoin(self.url, "{}/tiff_metadata/".format(mbv_id))
        data = self.get_request(url, format=format, params={"camera_key": camera_key})
        return data


class Cam(BaseResource):
    url = "/api/cams/"

    def get_cam_ids_from_serial(self, camera_serial):
        """Given a camera serial, gets the camera ids that correspond. SNs are not unique"""
        url = urllib.parse.urljoin(self.url, "?serial={}".format(camera_serial))
        data = self.get_request(url, format="json")
        if data:
            return [x["id"] for x in data]

    def update(self, id_, data):
        """
        Partial PATCH to update attributes of a Cam.

        Parameters
        ----------
        data: dict
            {attribute: value for attribute you want to update to value on the model}
        """

        url = urllib.parse.urljoin(self.url, "{}/".format(id_))
        data.update({"partial": True})
        resp = self.patch_request(url, data, params={"format": "json"})

        return resp


class CamSystem(BaseResource):
    url = "/api/camsystems/"

    def list(self, **kwargs):
        data = self.get_request(self.url, params=kwargs)
        return data

    def get_most_recent_camera(self, name, format="json"):
        data = self.get_request(self.url, {"name": name, "order": "-id"}, format=format)
        if data:
            return data[0]
        else:
            return {}

    def get_stack_order(self, camsys_id, format="json"):
        url = urllib.parse.urljoin(self.url, "{}/get_stack_order/".format(camsys_id))
        data = self.get_request(url, format=format)
        return data

    def get_ila_order(self, camsys_id, format="json"):
        url = urllib.parse.urljoin(self.url, "{}/get_ila_order/".format(camsys_id))
        data = self.get_request(url, format=format)
        return data


class FlightILATiePoints(APIRequester):
    def get(self, flight_id, allow_untested=False, format="json"):
        """Retrieves all ILAs for cameras on flight"""
        url = "/api/flight/{}/ila_tiepoints".format(flight_id)
        params = {}
        if allow_untested:
            params["allow_untested"] = True
        data = self.get_request(url, format=format, params=params)
        return data


class ILATiePoint(BaseResource):
    url = "/api/ila_tiepoints/"

    def list(self, **kwargs):
        data = self.get_request(self.url, params=kwargs)
        return data

    def retrieve(self, ila_tiepoint_id, format="json"):
        """Retrieves a solution by solution ID"""
        url = urllib.parse.urljoin(self.url, "{}/".format(ila_tiepoint_id))
        data = self.get_request(url, format=format)
        return data

    def create(
        self,
        reference_camera=None,
        warp_camera=None,
        valid_datetime=None,
        tiepoints_reference_camera=None,
        tiepoints_warp_camera=None,
        test_passed=False,
        reference_trim=None,
        warp_trim=None,
        flight_id=None,
        author=None,
    ):
        data = {
            "reference_camera": reference_camera,
            "warp_camera": warp_camera,
            "flight": flight_id,
            "images_collected_at": valid_datetime.isoformat(),
            "tiepoints_warp_camera": tiepoints_warp_camera,
            "tiepoints_reference_camera": tiepoints_reference_camera,
            "test_passed": test_passed,
        }
        if warp_trim is not None:
            data["warp_trim"] = warp_trim

        if reference_trim is not None:
            data["reference_trim"] = reference_trim

        if author is not None:
            data["author"] = author

        resp = self.post_request(self.url, data, params={"format": "json"})
        return resp

    def get_production_solution(
        self, reference_camera_pk, warp_camera_pk, flight_date=None, **kwargs
    ):
        """Gets the latest tested ILA solution (if exists) for a given set
        of camera serials."""
        params = {"format": "json"}
        params.update(kwargs)
        if flight_date:
            params["flight_date"] = flight_date
        url = urllib.parse.urljoin(
            self.url, "production/{}/{}/".format(reference_camera_pk, warp_camera_pk)
        )
        data = self.get_request(url, params=params)

        return data

    def get_testing_solution(
        self, reference_camera_pk, warp_camera_pk, flight_date=None, **kwargs
    ):
        """Gets the latest ILA solution (if exists) for a given set
        of camera serials, regardless of its testing status."""
        params = {"format": "json"}
        params.update(kwargs)
        if flight_date:
            params["flight_date"] = flight_date
        url = urllib.parse.urljoin(
            self.url, "testing/{}/{}/".format(reference_camera_pk, warp_camera_pk)
        )
        data = self.get_request(url, params=params)

        return data

    def approve_ila_solution(self, reference_camera_pk, warp_camera_pk):
        """Sets the ILA solution as valid (meaning it was tested by a human
        using images)."""
        solution = self.get_testing_solution(reference_camera_pk, warp_camera_pk)
        if solution:
            url = urllib.parse.urljoin(self.url, "{}/".format(solution["id"]))
            data = {"test_passed": "true", "partial": True}
            resp = self.patch_request(url, data, params={"format": "json"})
            return resp
        return "No untested ILA solution found."


class Farm(BaseResource):
    url = "/api/farms/"

    def create(self, name, customer_id):
        data = {"name": name, "customer": customer_id}
        resp = self.post_request(self.url, data, params={"format": "json"})
        return resp

    def list(self, **kwargs):
        params = {"format": "json"}
        params.update(kwargs)
        return self.get_request(self.url, params)


class Field(APIRequester):
    def __init__(self, auth_token=None, base_url=None):
        super(Field, self).__init__()
        self.url = "/api/fields/"

    def list(self, **kwargs):
        params = {"format": "json"}
        params.update(kwargs)
        return self.get_request(self.url, params)

    def retrieve(self, field_id, format="json"):
        url = urllib.parse.urljoin(self.url, "{}/".format(field_id))
        data = self.get_request(url, format=format)
        return data

    def create(self, geojson, name=None, customer_id=0, farm_id=None):
        data = {
            "name": name,
            "geojson": geojson,
            "customer": customer_id,
            "farm_future_id": farm_id,
        }
        resp = self.post_request(self.url, data, params={"format": "json"})
        return resp

    def update(self, id, geojson):
        url = urllib.parse.urljoin(self.url, "{}/".format(id))
        data = {"geojson": geojson, "partial": True}
        resp = self.patch_request(url, data, params={"format": "json"})
        return resp

    def get_geojson(self, field_id, mosaic_block=None, compact=False):
        """Get the GeoJSON of a field, optionally limited by block"""
        url = urllib.parse.urljoin(self.url, "{}/geos/".format(field_id))

        params = {}
        if mosaic_block:
            params["mosaic_block"] = mosaic_block
        if compact:
            params["compact"] = "true"

        resp = self.get_request(url, format="json", params=params)
        return resp

    def get_bounding_box(self, field_id):
        """Returns a GeoJSON bounding box for the entire field."""
        url = urllib.parse.urljoin(self.url, "{}/bounding_box/".format(field_id))
        response = self.get_request(url)
        return response


class Overlay(BaseResource):
    url = "/api/overlays/"

    def list(self, page=None, query_params=None):
        if query_params is None:
            query_params = {}

        if page is not None:
            query_params["page"] = page

        resp = self.get_request(self.url, query_params)
        return resp

    def create(self, data):
        resp = self.post_request(self.url, data)
        return resp

    def publish(self, overlay_id):
        url = urllib.parse.urljoin(self.url, "{}/publish/".format(overlay_id))
        resp = self.post_request(url, data={})
        return resp

    def bulk_publish(self, overlay_ids):
        url = urllib.parse.urljoin(self.url, "publish/")
        resp = self.post_request(url, data={"overlay_ids": overlay_ids})
        return resp

    def unpublish(self, overlay_id):
        url = urllib.parse.urljoin(self.url, "{}/unpublish/".format(overlay_id))
        resp = self.post_request(url, data={})
        return resp

    def delete(self, overlay_id):
        url = urllib.parse.urljoin(self.url, "{}/".format(overlay_id))
        resp = self.delete_request(url)
        return resp

    def create_or_update(self, data):
        url = "/api/overlays/create_or_update/"
        resp = self.post_request(url, data)
        return resp

    def create_custom_overlay(
        self, visit_id, geojson, overlay_type="custom", publish=True
    ):
        url = "/api/trees/custom/"
        data = {
            "visit_id": visit_id,
            "geojson": geojson,
            "publish": publish,
            "overlay_type": overlay_type,
        }
        resp = self.post_request(url, data)
        return resp

    def update_colors(self, overlay_id, colors):
        url = urllib.parse.urljoin(self.url, "{}/update_colors/".format(overlay_id))
        resp = self.patch_request(url, data=colors)
        return resp


class Tree(APIRequester):
    timeout_read = 120.0
    retries = 0
    url = "/api/trees/overlay/{}/"
    FEATURES_PER_PAGE = 10000

    def get_last_tree_count_overlay(self, field_id):
        query_params = {
            "field_id": field_id,
            "source": "tree_count",
            "ordering": "-created_at",
        }

        overlays = Overlay().list(query_params=query_params)
        if overlays.get("count", 0) > 0:
            overlay = overlays.get("results")[0]
            visit_id = overlay.get("visit")
        else:
            overlay = None
            visit_id = None

        return visit_id, overlay

    def retrieve(
        self, field_id, visit_id=None, format_="json", ids_only=False, block_id=None
    ):
        """Retrieve all the trees for a Field for a certain visit."""
        return_data = {
            "type": "FeatureCollection",
            "crs": {"type": "name", "properties": {"name": "EPSG:4326"}},
            "features": [],
        }

        # If visit not provided we will fetch the last tree_count overlay for this field to get the visit_id.
        if visit_id is None:
            visit_id, overlay = self.get_last_tree_count_overlay(field_id)
        else:
            query_params = {
                "visit_id": visit_id,
                "source": "tree_count",
                "ordering": "-created_at",
            }
            overlays = Overlay().list(query_params=query_params)
            if overlays.get("count", 0) > 0:
                overlay = overlays.get("results")[0]

        if visit_id is not None:
            url = self.url.format(overlay.get("id"))

            all_data = []
            finished = False
            page = 1
            while finished is False:
                print("Fetching Page {}".format(page))
                data = self.get_request(
                    url,
                    format=format_,
                    params={"page": page, "ids_only": ids_only, "block_id": block_id},
                )
                if data:
                    all_data.extend(data)
                    page += 1
                else:
                    finished = True

            print("Fetched {} trees".format(len(all_data)))

            if ids_only:
                return_data = [data[0] for data in all_data]
            else:
                for element in all_data:
                    id_ = element[0]
                    geometry = element[1]
                    varietal = element[2]
                    is_present = element[3]
                    row_number = element[4]
                    plant_number = element[5]
                    on_edge = element[6]

                    if len(element) > 7:
                        on_boundary = element[7]
                    else:
                        on_boundary = None

                    feature = {
                        "type": "Feature",
                        "id": id_,
                        "geometry": geometry,
                        "properties": {
                            "varietal": varietal,
                            "is_present": is_present,
                            "row_number": row_number,
                            "plant_number": plant_number,
                            "on_edge": on_edge,
                            "on_boundary": on_boundary,
                        },
                    }
                    return_data["features"].append(feature)
        else:
            return_data = {"error": "Tree count overlay does not exist."}
        return return_data

    def _calculate_number_of_pages(self, features):
        """Calculate the number of pages to send."""
        len_features = len(features)
        pages = int(len_features / self.FEATURES_PER_PAGE)
        if len_features % self.FEATURES_PER_PAGE:
            pages += 1
        return pages

    def delete_trees(self, visit_id):
        """Delete the trees for a certain field."""
        success = False

        query_params = {
            "visit_id": visit_id,
            "source": "tree_count",
        }

        overlays = Overlay().list(query_params=query_params)
        if overlays.get("count") == 1:
            overlay = overlays.get("results")[0]
            overlay_id = overlay.get("id")
            url = self.url.format(overlay_id)

            print("Deleting Overlay Asynchronously", overlay_id)
            resp = self.delete_request(url, params={"format": "json"})

            if resp == {"status_code": 204}:
                print("Overlay is deleting async. Waiting until it finishes")
                while not success:
                    sleep(10)
                    overlay = Overlay().retrieve(overlay_id)
                    success = overlay.get("detail") == "Not found."
                if not success:
                    print("Overlay was not deleted. Maybe it's taking too long?")
            else:
                print("There was a problem deleting the Overlay.")
                print(resp)
        else:
            print("No overlays found.")
            success = True
        return success

    def _get_or_create_trees_overlay(self, visit_id):
        overlays = (
            Overlay()
            .list(query_params={"visit_id": visit_id, "source": "tree_count"})
            .get("results")
        )
        if overlays:
            overlay = overlays[0]
        else:
            data = {
                "visit": visit_id,
                "source": "tree_count",
                "overlay_type": "tree_count",
                "published": False,
                "extra_data": {"processing": True},
            }
            overlay = Overlay().create(data)
        return overlay

    def _get_or_create_pli_overlay(
        self, visit_id, overlay_type, only_get=False, extra_data=None
    ):
        overlay = None
        query_params = {
            "visit_id": visit_id,
            "source": "tree_data",
            "overlay_type": overlay_type,
        }
        overlays = Overlay().list(query_params=query_params).get("results")
        if overlays:
            overlay = overlays[0]
        elif not only_get:
            base_extra_data = {"processing": True}

            if extra_data is not None:
                base_extra_data.update(extra_data)

            data = {
                "visit": visit_id,
                "source": "tree_data",
                "overlay_type": overlay_type,
                "published": False,
                "extra_data": base_extra_data,
            }
            overlay = Overlay().create(data)
        return overlay

    def _wait_for_finish(self, overlay_id):
        finished = False
        success = True

        print("Waiting Async upload to finish")
        while not finished:
            sleep(10)
            overlay = Overlay().retrieve(overlay_id)
            extra_data = overlay.get("extra_data", {})
            failed = extra_data.get("failed", False)
            finished = (not extra_data.get("receiving")) or failed
            success = not failed

        return success

    def create(
        self, visit_id, trees=None, missing_trees=None, delete=True, publish=False
    ):
        """Create all trees for a field in batches."""
        success = False

        if delete:
            deleted_or_skipped = self.delete_trees(visit_id)
        else:
            deleted_or_skipped = True

        overlay = self._get_or_create_trees_overlay(visit_id)
        overlay_id = overlay.get("id")

        if deleted_or_skipped:
            if missing_trees is not None:
                features = missing_trees.get("features")
                success = self._create_trees_pages(overlay_id, features, missing=True)

            if trees is not None:
                features = trees.get("features")
                success = self._create_trees_pages(overlay_id, features)

            if success:
                finished = self._wait_for_finish(overlay_id)
                if not finished:
                    success = False
                    url = urllib.parse.urljoin(
                        self.get_api_base(), "/overlays/{}".format(overlay_id)
                    )
                    print(
                        "Overlay upload failed or it's taking too long. "
                        "Please check in the Overlays page {} or contact the Works team".format(
                            url
                        )
                    )

        if success and publish:
            published = False
            resp = Overlay().publish(overlay_id)
            if resp.get("published", False):
                published = True

            if not published:
                print(
                    "There was a problem publishing the trees. Please check the trees status."
                )
                print(resp)

        return success

    def _create_trees_pages(self, overlay_id, features, missing=False):
        """Create the trees in batches."""
        url = self.url.format(overlay_id)
        key = "missing_trees" if missing else "trees"

        pages = self._calculate_number_of_pages(features)
        print(
            "Creating {} {} in {} batches of {}".format(
                len(features), key, pages, self.FEATURES_PER_PAGE
            )
        )

        for i in range(pages):
            print("Sending {} for page {}".format(key, i + 1))
            page_features = features[
                i * self.FEATURES_PER_PAGE : i * self.FEATURES_PER_PAGE
                + self.FEATURES_PER_PAGE
            ]

            trees = []
            for feature in page_features:
                properties = feature.get("properties")
                feature_data = [
                    feature.get("geometry").get("coordinates"),
                    properties.get("varietal"),
                    properties.get("row_number"),
                    properties.get("plant_number"),
                    properties.get("on_edge"),
                    properties.get("on_boundary"),
                ]
                trees.append(feature_data)

            payload = {
                key: trees,
                "page": i + 1,
                "total_pages": pages,
            }
            resp = self.post_request(url, payload, params={"format": "json"})
            if resp != {"status_code": 201}:
                print(
                    "There was a problem creating the trees. Please check the Overlay status."
                )
                print(resp)
                return False
        print("All {} uploaded".format(key))
        return True

    def update_varietals(self, overlay_id, data):
        """Insert data for the trees of a field."""
        overlay = Overlay().retrieve(overlay_id)
        url = self.url.format(overlay_id)

        resp = self.patch_request(url, data, params={"format": "json"})
        if resp != {"status_code": 201}:
            print(
                "There was a problem creating the trees data. Please check the Overlay status."
            )
            return False
        return True

    def update_row_numbers(self, overlay_id, data):
        """Insert data for the trees of a field."""
        url = "/api/trees/overlay/row-numbers/{}".format(overlay_id)

        resp = self.patch_request(url, data, params={"format": "json"})
        if resp != {"status_code": 201}:
            print(
                "There was a problem updating row numbers. Please check the Overlay status."
            )
            print(resp)
            return False
        return True

    def delete_data(self, visit_id, overlay_type):
        query_params = {
            "visit_id": visit_id,
            "source": "tree_data",
            "overlay_type": overlay_type,
        }
        overlays = Overlay().list(query_params=query_params).get("results")
        if overlays:
            overlay = overlays[0]
            overlay_id = overlay.get("id")

            print("Overlay is deleting async. Waiting until it finishes")
            Overlay().delete(overlay_id)

            success = False
            while not success:
                sleep(10)
                overlay = Overlay().retrieve(overlay_id)
                success = overlay.get("detail") == "Not found."
            if not success:
                print("Overlay was not deleted. Maybe it's taking too long?")

    def retrieve_data(self, overlay_id, block_id=None):
        url = "/api/trees/data/{}".format(overlay_id)

        if block_id is not None:
            url += "/" + block_id

        data = self.get_request(url, format="json")
        return data

    def download(self, overlay_id):
        url = "/api/trees/download/{}".format(overlay_id)
        data = self.get_request(url, format="json")
        return data

    def insert_data(self, visit_id, overlay_type, data, delete=True, color_breaks=None):
        """Insert data for the trees of a field."""
        if delete:
            print(
                "Deleting all data for visit: {} overlay_type: {}".format(
                    visit_id, overlay_type
                )
            )
            self.delete_data(visit_id, overlay_type)

        overlay = self._get_or_create_pli_overlay(visit_id, overlay_type)
        overlay_id = overlay.get("id")

        pages = self._calculate_number_of_pages(data)
        print(
            "Creating {} tree data points in {} batches of {}".format(
                len(data), pages, self.FEATURES_PER_PAGE
            )
        )
        for i in range(pages):
            print("Sending page {}".format(i + 1))
            page_data = data[
                i * self.FEATURES_PER_PAGE : i * self.FEATURES_PER_PAGE
                + self.FEATURES_PER_PAGE
            ]

            payload = {
                "visit_id": visit_id,
                "overlay_type": overlay_type,
                "data": [
                    [elem.get("tree"), elem.get("value"), elem.get("color")]
                    for elem in page_data
                ],
                "page": i + 1,
                "total_pages": pages,
            }

            if i == 0:
                payload["color_map"] = color_breaks

            url = "/api/trees/data/{}/".format(overlay_id)
            resp = self.post_request(url, payload, params={"format": "json"})
            if resp != {"status_code": 201}:
                print(
                    "There was a problem creating the trees data. Please check the trees status."
                )
                print(resp)
                return False

        finished = self._wait_for_finish(overlay_id)
        if not finished:
            url = urllib.parse.urljoin(
                self.get_api_base(), "/overlays/{}".format(overlay_id)
            )
            print(
                "Overlay upload failed or it's taking too long. "
                "Please check in the Overlays page {} or contact the Works team".format(
                    url
                )
            )

        return finished


class FlyingService(BaseResource):
    url = "/api/flying_services/"


class Flight(APIRequester):
    def __init__(self):
        super(Flight, self).__init__()
        self.url = "/api/flights/"

    class Status:
        PENDING_OPS = "Pending Ops"
        IN_PROGRESS = "In Progress"
        CHECKING_COVERAGE = "Checking Coverage"
        FAILED_MECHANICAL = "Failed - Mechanical"
        FAILED_WEATHER = "Failed - Weather"
        FAILED_PILOT = "Failed - Pilot"
        FAILED_HARDWARE = "Failed - Hardware"
        COMPLETE_PARTIAL = "Complete - Partial"
        CANCELED = "Canceled"
        COMPLETE = "Complete"
        SCHEDULED = "Scheduled"

    def change_status(self, id, new_status_name):
        url = urllib.parse.urljoin(self.url, "{}/change_status/".format(id))
        data = {"new_status_name": new_status_name}
        resp = self.post_request(url, data)
        return resp

    def retrieve(self, flight_id):
        url = urllib.parse.urljoin(self.url, "{}/".format(flight_id))
        params = {"format": "json"}
        flightplan_geojson = self.get_request(url, params)
        data = {"plan_geojson": flightplan_geojson}
        return data

    def get_data_for_satellite(self, flight_id):
        url = urllib.parse.urljoin(self.url, "{}/satellite_data/".format(flight_id))
        params = {"format": "json"}
        data = self.get_request(url, params)
        return data

    def update(self, id, changes):
        url = urllib.parse.urljoin(self.url, "{}/".format(id))
        resp = self.patch_request(url, changes, params={"format": "json"})
        return resp

    def list(
        self,
        date=None,
        min_date=None,
        max_date=None,
        cam_system=None,
        exclude_cancelled=False,
        flight_time_utc__gte=None,
        flight_time_utc__lt=None,
    ):
        """
        Returns a list of flights filtered by date or camera specifications.

        Parameters
        ----------
        cam_system : int
            camera system ID, not name
        date : str
            filter flights by specific date in YYYY-MM-DD format.
        min_date : str
        max_date : str
        cam_system : int
            id of camera system to filter by
        exclude_cancelled : bool
            whether to exclude cancelled flights (default False)
        flight_date__gte : str
            Lower bound (inclusive) for datetime filtering. Date time string should be provided ISO-8601 (subset) format
            (ie "YYYY-mm-ddTHH:MM:SS"). *No TZ info is accepted*, but flight_times are stored in UTC, so these datetimes
            are treated to be UTC as well.
        flight_time_utc__lt : str
            Upper bound (exclusive) for datetime filtering.

        Returns
        -------

        """

        date_re = re.compile(r"^\d{4}-\d{2}-\d{2}$")
        types = {
            "date": str,
            "max_date": str,
            "min_date": str,
            "cam_system": int,
            "flight_time_utc__gte": str,
            "flight_time_utc__lt": str,
        }
        params = {
            "date": date,
            "min_date": min_date,
            "max_date": max_date,
            "cam_system": cam_system,
            "flight_time_utc__gte": flight_time_utc__gte,
            "flight_time_utc__lt": flight_time_utc__lt,
        }

        # check types and that only date or date range are specified:
        if date and (min_date or max_date):
            raise ValueError(
                "Specific date cannot be combined with date range parameters (min or max)"
            )
        for k, v in params.items():
            if v is not None and type(v) is not types[k]:
                raise TypeError("Supplied value for {} parameter is incorrect.")
            elif k.endswith("date") and v is not None:
                if date_re.match(v) is None:
                    raise ValueError(
                        'Date specified "{}" is formatted incorrectly - should be YYYY-MM-DD.'.format(
                            v
                        )
                    )
        if exclude_cancelled:
            cancelled_names = [
                "Failed - Hardware",
                "Failed - Pilot",
                "Failed - Other",
                "Failed - Weather",
                "Failed - Did Not Cover",
                "Canceled",
            ]
            params["exclude_status_names"] = ",".join(cancelled_names)
        params["format"] = "json"

        return self.get_request(self.url, params)


class ProductComponent(BaseResource):
    url = "/api/product_components/"


class RepeatingTimer(TimerClass):
    """
    A daemonic thread that executes a function on an interval.
    """

    def __init__(self, interval, function, *args, **kwargs):
        super(RepeatingTimer, self).__init__(interval, function, *args, **kwargs)
        self.daemon = True

    def run(self):
        while not self.finished.is_set():
            self.finished.wait(self.interval)
            if not self.finished.is_set():
                try:
                    self.function(*self.args, **self.kwargs)
                except Exception as exception:
                    print("Unhandled exception, {}".format(exception))


class ProcessingEvent(APIRequester):
    """Base class for logging Improc events with CeresWorks REST endpoint.

    Call create() on the start of a processing step and update() on the end of a processing step.s


    Several convenience types are defined for specific events, allowing for consistent use of process naming
    convention. This base class can also be used to log arbitrary events in the CeresWorks improc logging database.

    Examples
    ---
    >>> # report the start of a block uploading:
    >>> import worksclient as wc
    >>> flight_id = 4; field_id = 55; mosaic_block_letter = 'A'
    >>> obj_id = wc.MosaicBlockVisit.create(flight_id, field_id, mosaic_block_letter).get('id')  # doctest: +SKIP
    >>> proc_id = wc.BlockUploadEvent.start(obj_id).get('id') # doctest: +SKIP
    >>> # Do something here that you want to log.
    >>> wc.BlockUploadEvent.finish(proc_id, result='completed') # doctest: +SKIP
    >>> # or wc.BlockUploadEvent.fail(proc_id, exception='There was an error that we are logging'
    """

    url = "/api/process_log/"
    process_name = None
    object_key = None  # specify which object type is being processed. (ie. 'flight_id', 'visit_id', ...)
    timers = {}

    def start(self, object_id, process_name=None, interval=0):
        """Generates a POST for the start of a processing step for a specific data object.

        Generally process names are defined by subclasses of the
        ProcessingEvent, but the server API can handle arbitrary process names.
        To use this functionality, use the ProcessingEvent class directly.

        Parameters
        ----------
        object_id : int
            Object identifier explaining the object that the process is working
            on. For flights, this is simply the flight_id integer. For mosaic
            blocks is the output from:
            `MosaicBlockVisit.create(
                flight_id, field_id, mosaic_block_letter).get('id')`
        process_name : str
            When left to the default value, this will use the process_name
            attribute of the ProcessingEvent sub-class. When used for an
            arbitrary processing step, use the ProcessingEvent class directly
            and specify the name of the process step.
        interval : int
            Interval in seconds to do heartbeat.  Defaults to 0 and does not do
            heartbeat.

        Returns
        --------
        dict
            This returns the HTTP response dictionary. When successful, an 'id'
            field is returned that will be used in subsequent modifications of
            the event status. ALWAYS use the get('id') method to retrieve the
            process_id, as it will allow the function to run even if the
            logging server is not accessible.
        """

        if process_name is None:
            process_name = self.process_name
        if not process_name:
            # this will happen if using the BlockProcessingEvent base class with no specified process name.
            raise ValueError("Process name must be specified.")

        data = {
            self.object_key: object_id,
            "process_name": process_name,
            "process_computer": HOSTNAME,
            "heartbeat_interval": interval,
        }

        resp = self.post_request(self.url, data)
        process_id = resp.get("id")
        if interval:
            self.timers[process_id] = RepeatingTimer(
                interval, self.heartbeat, [process_id]
            )
            self.timers[process_id].start()
        return resp

    def finish(self, process_id, result=None):
        """Marks the process as finished.

        Parameters
        ----------
        process_id : int
            Process id returned from the ProcessEvent.start().get('id') method.
        result : str
        """

        data = {"id": process_id, "result": result}
        url = urllib.parse.urljoin(self.url, "{}/".format(process_id))
        # stop the timer before finishing the request since it finished
        timer = self.timers.get(process_id)
        if timer is not None:
            timer.cancel()
        resp = self.patch_request(url, data)
        return resp

    def fail(self, process_id, exception):
        """Marks the process as failed

        Parameters
        ----------
        process_id : int
            Process id returned from the ProcessEvent.start().get('id') method.
        exception: str
            Debugging information to be logged.
        """

        data = {"id": process_id, "exception": exception}
        url = urllib.parse.urljoin(self.url, "{}/".format(process_id))
        resp = self.patch_request(url, data)
        # stop the timer after finishing the request since it failed
        timer = self.timers.get(process_id)
        if timer is not None:
            timer.cancel()
        return resp

    def heartbeat(self, process_id):
        """Transmits heartbeat for a process to allow determination by the server if it is still alive.

        Parameters
        ----------
        process_id
        status_update

        Returns
        -------

        """
        if not process_id:
            return {}
        data = {"id": process_id}
        url = urllib.parse.urljoin(self.url, "{}/".format(process_id))
        resp = self.patch_request(url, data)
        return resp

    def get_by_flight_id(self, flight_id):
        """Returns a set of ProcessLog objects associated with a Flight."""
        data = self.get_request(self.url, params={"flight_id": flight_id})
        return data


class BlockProcessingEvent(ProcessingEvent):
    """Generic event for a block processing event.
    No process_name is specified, so if you use this, you must call start() with a process_name string."""

    object_key = "mosaic_block_visit"


class BlockUploadEvent(BlockProcessingEvent):
    process_name = "upload"


class BlockStackEvent(BlockProcessingEvent):
    process_name = "stack"


class BlockRegistrationEvent(BlockProcessingEvent):
    process_name = "registration"


class BlockMosaicEvent(BlockProcessingEvent):
    process_name = "mosaic"


class BlockCandidateGenerationEvent(BlockProcessingEvent):
    process_name = "candidate_image_generation"


class BlockCandidateSelectionEvent(BlockProcessingEvent):
    process_name = "candidate_image_selection"


class FlightProcessingEvent(ProcessingEvent):
    object_key = "flight"


class FlightPreprocessingEvent(FlightProcessingEvent):
    process_name = "preprocessing"


class FlightPreprocessWaitingEvent(FlightProcessingEvent):
    process_name = "preprocess_waiting"


class FlightPreprocessCameraTransferEvent(FlightPreprocessingEvent):
    process_name = "preprocess_camera_transfer"


class FlightPreprocessUploadingEvent(FlightProcessingEvent):
    process_name = "preprocess_uploading"


class VisitProcessingEvent(BlockProcessingEvent):
    object_key = "visit"


class VisitReadyToStackEvent(VisitProcessingEvent):
    process_name = "check_if_ready_to_stack"


class FlightCamCorrections(APIRequester):
    def retrieve(self, flight_id, format="json", **kwargs):
        url = "/api/flights/{}/camera_correction".format(flight_id)
        data = self.get_request(url, format=format, raise_for_status=True)
        return data


class UserSettings(BaseResource):
    url = "/api/users/settings/"

    def list(self, setting=None, user_ids=None):  # pylint: disable=arguments-differ
        params = {"format": "json"}
        url = self.url

        if setting is not None:
            params["setting"] = setting

        if user_ids is not None:
            url += "?%s" % urllib.parse.urlencode([("user_id", x) for x in user_ids])

        return self.get_request(url, params)


class BaseGrid(BaseResource):
    url = "/api/grids/base/{}/"

    def list(self, overlay_id, grid_type_id=None):  # pylint: disable=arguments-differ
        url = self.url.format(overlay_id)
        if grid_type_id is not None:
            url += str(grid_type_id)

        return self.get_request(url)


class Grid(BaseGrid):
    url = "/api/grids/{}/"


class DisplayField(BaseResource):
    url = "api/display_field/"

    def create(self, data):
        resp = self.post_request(self.url, data)
        return resp


class FieldRank(BaseResource):
    url = "api/field_rank/{}/"

    def set(self, visit_id, field_rank):
        resp = self.patch_request(self.url.format(visit_id), {"field_rank": field_rank})
        return resp


class Pinterface(BaseResource):
    url = "api/ra/pinterface_visit/"

    def get_url(self, visit_id, email):
        return self.post_request(self.url, {"visit_id": visit_id, "email": email})


class CustomLayer(BaseResource):
    url = "api/custom-layers/new/"

    def create(
        self,
        file,
        style,
        name,
        customer,
        farm=None,
        field=None,
        description=None,
        enabled=True,
    ):
        params = {
            "style": style,
            "name": name,
            "customer": customer,
            "farm": farm,
            "field": field,
            "description": description,
            "enabled": enabled,
        }
        return self.post_file_request(self.url, {"files": file}, params=params)


class RMADate(BaseResource):
    url = "api/insurance/rma/dates"

    def fetch(
        self, year, commodity, plan, state, county, date_type
    ):  # pylint: disable=too-many-arguments
        url = "/".join(
            (
                self.url,
                "fetch",
                str(year),
                str(commodity),
                str(plan),
                str(state),
                str(county),
                date_type,
            )
        )
        return self.get_request(url)


class Satellite(BaseResource):
    url = "/api/satellite/"

    class AssetStatus:
        WAITING_QA = "WAITING_QA"
        QA_PASSED = "QA_PASSED"
        QA_REJECTED = "QA_REJECTED"
        OTHER = "OTHER"

    class ExternalGeoObjectStatus:
        RECEIVED = "RECEIVED"
        READY_TO_DELIVER_REPORT = "READY_TO_GENERATE_REPORT"
        REPORT_DELIVERED = "REPORT_DELIVERED"
        ERROR = "ERROR"

    def get_fields(self):
        """Returns fields with satellite profiles."""
        url = urllib.parse.urljoin(self.url, "fields/")
        return self.get_request(url)

    def create_asset(self, data):
        url = urllib.parse.urljoin(self.url, "assets/")
        resp = self.post_request(url, data)
        return resp

    def get_asset(self, asset_id):
        """Returns a particular SatelliteAsset."""
        url = urllib.parse.urljoin(self.url, "assets/{}/".format(asset_id))
        return self.get_request(url)

    def get_pending_assets(self, field_id):
        """Returns a list of SatelliteAssets pending human QA."""
        url = urllib.parse.urljoin(
            self.url,
            "fields/{}/assets/?asset_status={}".format(
                field_id, self.AssetStatus.WAITING_QA
            ),
        )
        return self.get_request(url)

    def get_approved_assets(self, field_id):
        """Returns a list of SatelliteAssets that passed human QA. For now, it defaults to CLIPPED_GEOTIFF."""
        url = urllib.parse.urljoin(
            self.url,
            "fields/{}/assets/?asset_status={}".format(
                field_id, self.AssetStatus.QA_PASSED
            ),
        )
        return self.get_request(url)

    def get_rejected_assets(self, field_id):
        """Returns a list of SatelliteAssets that failed human QA."""
        url = urllib.parse.urljoin(
            self.url,
            "fields/{}/assets/?asset_status={}".format(
                field_id, self.AssetStatus.QA_REJECTED
            ),
        )
        return self.get_request(url)

    def change_asset_status(self, asset_id, new_status_name):
        """Change the status of a Satellite Asset (usually regarding its cloudiness)."""
        url = urllib.parse.urljoin(
            self.url, "assets/{}/change_status/".format(asset_id)
        )
        data = {"new_status_name": new_status_name}
        resp = self.post_request(url, data)
        return resp

    def change_external_geo_object_status(
        self, external_geo_object_id, new_status_name
    ):
        """Change the status of an ExternalGeoObject (usually to indicate that assets have been generated for that
        geometry)."""
        url = urllib.parse.urljoin(
            self.url,
            "external_geo_objects/{}/change_status/".format(external_geo_object_id),
        )
        data = {"new_status_name": new_status_name}
        resp = self.post_request(url, data)
        return resp

    def create_additional_geo_data(
        self, external_geo_object_id, fungicides_zone_json, tachometer_choice
    ):
        """Takes a FeatureCollection GeoJSON and post the individual geometries to Works (mostly fungicides
        zones for Evergreen for now)."""
        url = urllib.parse.urljoin(self.url, "vra/")
        geo_type = "zone"
        tachometer_choice = {"tachometer_choice": tachometer_choice}

        data = {
            "external_geo_object": external_geo_object_id,
            "geo_type": geo_type,
            "geojson": fungicides_zone_json,
            "extra_data": tachometer_choice,
        }
        self.post_request(url, data)
