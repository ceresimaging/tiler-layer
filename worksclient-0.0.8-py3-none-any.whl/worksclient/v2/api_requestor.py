"""
v2 API client overrides
"""

import logging
import os

import six.moves.urllib as urllib

from worksclient.api_requestor import APIRequester as APIRequesterV1
from worksclient.util import show_errors
import worksclient as wc

LOGGER = logging.getLogger(__name__)


class APIRequestor(APIRequesterV1):
    @property
    def base_url(self):
        return NotImplementedError("resources must define a base URL")

    @property
    def filter_passthrough(self):
        return NotImplementedError(
            "if using @parse_filters, must implement filter_passthrough"
        )

    @show_errors
    def get_request(self, url, params=dict()):
        response = self.get_session().get(url, params=params)
        response.raise_for_status()

        if wc.DEBUG:
            # Per request from @geoffwall
            print(response.request.url)

        return response.json()

    @show_errors
    def patch_request(self, url, data=dict()):
        response = self.get_session().patch(url, json=data)
        response.raise_for_status()
        return response.json()

    @show_errors
    def post_request(self, url, data=dict()):
        response = self.get_session().post(url, json=data)
        response.raise_for_status()
        return response.json()

    def _make_url(self, *args, **kwargs):
        if kwargs.get("with_base", True):
            base = self.base_url
        else:
            base = "/"

        extra = os.path.join(base, *[str(a) for a in args])
        extra = extra.rstrip("/") + "/"  # ensure only one trailing slash
        url = urllib.parse.urljoin(self.get_api_base(), extra)
        return url

    def _autopage(self, url, envelope, params):
        """autopaginator for list endpoints"""
        results = []
        continue_paging = True

        while continue_paging:
            resp = self.get_request(url, params=params)
            results.extend(resp[envelope])
            current_page = resp["meta"]["page"]
            total_pages = resp["meta"]["total_pages"]
            LOGGER.debug("Fetching page {} of {}".format(current_page, total_pages))
            continue_paging = current_page < total_pages
            params["page"] = current_page + 1

        return results
