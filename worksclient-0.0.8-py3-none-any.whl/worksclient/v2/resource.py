# pylint: disable=unused-argument

import logging
from pprint import pformat

from worksclient.util import parse_filters, parse_includes, parse_sort

from .api_requestor import APIRequestor

LOGGER = logging.getLogger(__name__)


class BaseRequestor(APIRequestor):
    """
    This class is a hack to allow Asset requestor classes to request URLs further up than their own base_url.
    @TODO refactor the whole base_url approach?
    """

    @property
    def schema_ref(self):
        return NotImplementedError(
            "if using @parse_filters, must implement filter_passthrough"
        )

    def get_schema(self):
        schema_url = "/api/spec.json"
        url = self._make_url(schema_url, with_base=False).rstrip("/")
        schema = self.get_request(url)
        try:
            own_definition = schema["definitions"][self.schema_ref]
        except KeyError:
            raise Exception("No schema ref on file for this resource :(")
        print(pformat(own_definition))


class Field(BaseRequestor):

    base_url = "/api/v2/fields/"

    schema_ref = "FieldSerializerV2"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["id", "name", "auto_acres"],
        "include": [
            "customer",
            "displayfield",
            "farm",
            "flight_restriction",
            "region",
            "geojson",
            "boundary",
            "min_resolution",
        ],
        "filters": [
            "id",
            "customer",
            "farm",
            "flight_restriction",
            "region",
            "auto_acres",
            "region",
            "name",
            "qc_intensity",
        ],
    }

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        """
        Parameters
        ----------
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        filters: dict
            list of filters to apply to the request. NOTE: This is parsed by the @parse_filters
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        sort: str
            query sort, e.g. 'date', '-field.name'. NOTE: This is parsed by the @parse_sort
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        results: list
        """
        url = self._make_url()
        results = self._autopage(url=url, envelope="fields", params=params)
        return results

    @parse_includes
    def get(self, _id, params=None, include=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["field"]

    def update(self, _id, changes=None):
        url = self._make_url(_id)
        response = self.patch_request(url, data=changes)
        return response["field"]

    def create(self, data=None):
        url = self._make_url()
        response = self.post_request(url, data=data)
        return response["field"]

    def get_geojson(self, _id, mosaic_block=None, compact=False):
        """Get the GeoJSON of a field, optionally limited by block"""
        url = self._make_url(_id, "geos")

        params = {}
        if mosaic_block:
            params["mosaic_block"] = mosaic_block
        if compact:
            params["compact"] = "true"

        resp = self.get_request(url, params=params)
        return resp


class Flight(BaseRequestor):

    base_url = "/api/v2/flights/"

    schema_ref = "FlightSerializerV2"

    class Status:
        PENDING_OPS = "Pending Ops"
        IN_PROGRESS = "In Progress"
        CHECKING_COVERAGE = "Checking Coverage"
        FAILED_MECHANICAL = "Failed - Mechanical"
        FAILED_WEATHER = "Failed - Weather"
        FAILED_PILOT = "Failed - Pilot"
        FAILED_HARDWARE = "Failed - Hardware"
        FAILED_WILDFIRE = "Failed - Wildfire"
        COMPLETE_PARTIAL = "Complete - Partial"
        CANCELED = "Canceled"
        COMPLETE = "Complete"
        SCHEDULED = "Scheduled"

    OPTIONS = {
        "sort": ["date", "flight_time", "duration", "created_at", "id"],
        "filters": [
            "status",
            "pilot",
            "cam_system",
            "date",
            "flight_time",
            "duration",
            "id",
        ],
        "include": [
            "id",
            "status",
            "pilot",
            "cam_system",
            "visits",
            "flightplan",
            "flight_report",
        ],
    }

    filter_passthrough = []

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        """
        Parameters
        ----------
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        filters: dict
            list of filters to apply to the request. NOTE: This is parsed by the @parse_filters
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        sort: str
            query sort, e.g. 'date', '-field.name'. NOTE: This is parsed by the @parse_sort
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        results: list
        """
        url = self._make_url()
        results = self._autopage(url=url, envelope="flights", params=params)
        return results

    @parse_includes
    def get(self, _id, params=None, include=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["flight"]

    def update(self, _id, changes=None):
        url = self._make_url(_id)
        response = self.patch_request(url, data=changes)
        return response["flight"]

    def change_status(self, _id, new_status_name):
        url = self._make_url(_id, "change_status")
        data = {"new_status_name": new_status_name}
        response = self.post_request(url, data=data)
        return response


class FlyingService(BaseRequestor):

    base_url = "/api/v2/flying_services/"

    schema_ref = "FlyingServiceSerializerV2"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["id", "active", "internet_upload_speed", "price_per_hour"],
        "include": ["region", "current_camera_system"],
        "filters": [
            "region",
            "current_camera_system",
            "active",
            "price_per_hour",
            "name",
            "id",
        ],
    }

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        """
        Parameters
        ----------
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        filters: dict
            list of filters to apply to the request. NOTE: This is parsed by the @parse_filters
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        sort: str
            query sort, e.g. 'date', '-field.name'. NOTE: This is parsed by the @parse_sort
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        results: list
        """
        url = self._make_url()
        results = self._autopage(url=url, envelope="flying_services", params=params)
        return results


class Visit(BaseRequestor):

    base_url = "/api/v2/visits/"

    schema_ref = "VisitSerializerV2"

    class Status:
        PUBLISHED = "Published"
        REGISTERED = "Registered"
        FAILED_OTHER = "Failed - Other"
        FAILED_WEATHER = "Failed - Weather"
        FAILED_TIMEOFDAY = "Failed - Time of Day"
        UPLOADING = "Uploading"
        FAILED_COVERAGE = "Failed - Did Not Cover"
        PENDING_STACKING = "Pending Stacking (auto)"
        PENDING_MOSAICING = "Pending Mosaicing (auto)"

    filter_passthrough = [
        """ Add values here that should not be transformed into the dynamic-rest filter format """
        #  "status__name",
    ]

    OPTIONS = {
        "sort": ["id", "target_date", "start_time", "end_time", "flight.date"],
        "include": [
            "field",
            "flight",
            "product",
            "status",
            "imaging_strategy",
            "scheduled_geojson",
            "qc_intensity",
            "avian_url",
            "published_layers",
        ],
        "filters": [
            "field",
            "flight",
            "product",
            "status",
            "id",
            "target_date",
            "visit_type",
        ],
    }

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        """
        Parameters
        ----------
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        filters: dict
            list of filters to apply to the request. NOTE: This is parsed by the @parse_filters
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.
        sort: str
            query sort, e.g. 'date', '-field.name'. NOTE: This is parsed by the @parse_sort
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        results: list
        """
        url = self._make_url()
        results = self._autopage(url=url, envelope="visits", params=params)
        return results

    @parse_includes
    def get(self, _id, params=None, include=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["visit"]

    def update(self, _id, changes=None):
        url = self._make_url(_id)
        response = self.patch_request(url, data=changes)
        return response["visit"]

    def change_status(self, _id, new_status_name):
        url = self._make_url(_id, "change_status")
        data = {"new_status_name": new_status_name}
        response = self.post_request(url, data=data)
        return response

    def get_scheduled_geojson(self, _id, mosaic_block=None, compact=False):
        """Get the GeoJSON of a field, optionally limited by block"""
        url = self._make_url(_id, "scheduled_geos")

        params = {}
        if mosaic_block:
            params["mosaic_block"] = mosaic_block
        if compact:
            params["compact"] = "true"

        resp = self.get_request(url, params=params)
        return resp


class Pilot(BaseRequestor):

    base_url = "/api/v2/pilots/"

    schema_ref = "PilotSerializerV2"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["id", "active"],
        "include": ["flying_service"],
        "filters": ["flying_service", "name", "active"],
    }

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        url = self._make_url()
        results = self._autopage(url=url, envelope="pilots", params=params)
        return results

    @parse_includes
    def get(self, _id, params=None, include=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["pilot"]

    @parse_filters
    @parse_includes
    def get_schedule(self, _id, params=None, include=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id, "schedule")
        response = self.get_request(url, params=params)
        return response["pilot_schedules"]


class PilotSchedule(BaseRequestor):

    base_url = "/api/v2/pilot_schedules/"

    schema_ref = "PilotScheduleSerializerV2"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["date", "start_time", "end_time"],
        "include": ["pilot"],
        "filters": ["pilot", "date", "start_time", "end_time"],
    }

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        url = self._make_url()
        results = self._autopage(url=url, envelope="pilot_schedules", params=params)
        return results

    @parse_includes
    def get(self, _id, params=None, include=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["pilot_schedule"]


class User(BaseRequestor):

    base_url = "/api/v2/users/"

    schema_ref = "UserSerializerV2"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["id"],
        "include": ["user_profile"],
        "filters": ["id", "username", "email", "is_active", "user_profile"],
    }

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        url = self._make_url()

        results = self._autopage(url=url, envelope="users", params=params)
        return results

    @parse_includes
    @parse_filters
    @parse_sort
    def get(self, _id, params=None, include=None, filters=None, sort=None):
        """
        params: dict
            URL Query string arguments.
        include: list
            list of related objects to include. NOTE: This is parsed by the @parse_includes
            decorator and items inserted into the params kwarg. It is passed in here for
            reference.

        Returns
        -------
        dict
        """
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["user"]


class VisitWeather(BaseRequestor):
    base_url = "/api/v2/visit_weathers"
    schema_ref = "VisitWeatherSerializer"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["id", "variable", "service"],
        "filters": ["id", "variable", "service", "station", "visit", "value"],
        "include": ["id", "visit"],
    }

    @parse_includes
    def get(self, _id, params=None, include=None):
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["visit_weather"]

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        url = self._make_url()
        results = self._autopage(url=url, envelope="visit_weathers", params=params)
        return results

    def create(self, data=None):
        url = self._make_url()
        response = self.post_request(url, data=data)
        return response

    def update(self, _id, data=None):
        url = self._make_url(_id)
        response = self.patch_request(url, data=data)
        return response


class VisitStatistic(BaseRequestor):
    base_url = "/api/v2/visit_statistics"
    schema_ref = "VisitStatisticSerializer"

    filter_passthrough = []

    OPTIONS = {
        "sort": ["id", "variable", "product_version"],
        "filters": ["id", "variable", "statistic", "product_version", "visit", "value"],
        "include": ["id", "visit"],
    }

    @parse_includes
    def get(self, _id, params=None, include=None):
        url = self._make_url(_id)
        response = self.get_request(url, params=params)
        return response["visit_statistic"]

    @parse_includes
    @parse_filters
    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        url = self._make_url()
        results = self._autopage(url=url, envelope="visit_statistics", params=params)
        return results

    def create(self, data=None):
        url = self._make_url()
        response = self.post_request(url, data=data)
        return response

    def update(self, _id, data=None):
        url = self._make_url(_id)
        response = self.patch_request(url, data=data)
        return response


class CropVarietal(BaseRequestor):

    base_url = "/api/v2/varietals/"

    OPTIONS = {
        "sort": ["name"],
    }

    @parse_sort
    def list(self, params=None, include=None, filters=None, sort=None):
        url = self._make_url()
        results = self._autopage(url=url, envelope="crop_varietals", params=params)
        return results
